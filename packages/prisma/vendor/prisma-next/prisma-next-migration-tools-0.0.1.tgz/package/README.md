# @prisma-next/migration-tools

> **Internal package.** This package is an implementation detail of [`prisma-next`](https://www.npmjs.com/package/prisma-next)
> and is published only to support its runtime. Its API is unstable and may change
> without notice. Do not depend on this package directly; install `prisma-next` instead.

On-disk migration persistence, hash verification, and history reconstruction for Prisma Next.

## Responsibilities

- **Types**: Define the migration package shape (`MigrationMetadata`, `MigrationOps`, `MigrationPackage`, `MigrationGraph`)
- **I/O**: Read and write migration packages to/from disk (`migration.json` + `ops.json`)
- **Hashing**: Compute and verify content-addressed migration hashes for tamper detection
- **History reconstruction**: Reconstruct and navigate migration history (path finding, latest migration detection, cycle/orphan detection)

## Hash framing

`computeMigrationHash` in `hash.ts` uses explicit framing:

1. Strip identity-affecting fields (`migrationHash`, `signature`, `fromContract`,
   `toContract`, `hints`) from the metadata envelope, then canonicalize the
   stripped envelope and the ops array.
2. SHA-256 each canonical part independently.
3. SHA-256 the canonical JSON tuple `[hash(metadata), hash(ops)]`.

This avoids delimiter-ambiguity and pins `migrationHash` to a 2-tuple over
the on-disk storage shape. Per [ADR 199 — Storage-only migration identity],
contracts are anchored separately via storage-hash bookends inside the
metadata envelope, and planner hints are advisory and must not affect
identity.

[ADR 199 — Storage-only migration identity]: ../../../docs/architecture%20docs/adrs/ADR%20199%20-%20Storage-only%20migration%20identity.md

## Ops validation boundary

`readMigrationPackage` performs intentionally shallow `ops.json` validation in `io.ts`:

- validates envelope fields (`id`, `label`, `operationClass`)
- does not fully validate operation-specific payload shape

Full semantic validation happens in target/family migration planners and runners at execution/planning time.

## Architecture

```mermaid
graph TD
    CLI["CLI commands<br/>(migration new, plan, apply, show, status)"] --> IO["io.ts<br/>File I/O"]
    CLI --> HASH["hash.ts<br/>Migration hashing"]
    CLI --> GRAPH["migration-graph.ts<br/>Graph operations"]
    IO --> META["metadata.ts<br/>MigrationMetadata, MigrationHints"]
    IO --> PKG["package.ts<br/>MigrationPackage, MigrationOps"]
    HASH --> IO
    HASH --> CAN["canonicalize-json.ts"]
    HASH --> CP["@prisma-next/emitter<br/>canonicalizeContract"]
    GRAPH --> GR["graph.ts<br/>MigrationGraph, MigrationEdge"]
    GRAPH --> ABS["@prisma-next/migration-tools/constants<br/>EMPTY_CONTRACT_HASH"]
```

## Dependencies

| Package | Why |
|---|---|
| `@prisma-next/contract` | `Contract` type for embedded contracts in metadata |
| `@prisma-next/framework-components` | `MigrationPlanOperation` types (via `./control`) |
| `@prisma-next/emitter` | `canonicalizeContract` |
| `arktype` | Runtime shape validation for `migration.json` and `ops.json` |
| `@prisma-next/utils` | Workspace utility dependency (currently no direct runtime imports in this package) |
| `pathe` | Cross-platform path manipulation |

### Dependents

- `@prisma-next/cli` (M3) — CLI commands consume these functions

## Export Subpaths

| Subpath | Contents |
|---|---|
| `./metadata` | `MigrationMetadata`, `MigrationHints` |
| `./package` | `MigrationPackage`, `MigrationOps` |
| `./graph` | `MigrationGraph`, `MigrationEdge` |
| `./io` | `writeMigrationPackage`, `readMigrationPackage`, `readMigrationsDir`, `formatMigrationDirName` |
| `./hash` | `computeMigrationHash`, `verifyMigrationHash` |
| `./migration-graph` | `reconstructGraph`, `findLeaf`, `findPath`, `detectCycles`, `detectOrphans` |
| `./errors` | `MigrationToolsError` |
| `./constants` | `EMPTY_CONTRACT_HASH` |

## On-Disk Format

Each migration is a directory containing two files:

```
migrations/
  20260225T1430_add_users/
    migration.json    # MigrationMetadata
    ops.json          # MigrationPlanOperation[]
```

See [ADR 028](../../../docs/architecture%20docs/adrs/ADR%20028%20-%20Migration%20Structure%20%26%20Operations.md) and [ADR 001](../../../docs/architecture%20docs/adrs/ADR%20001%20-%20Migrations%20as%20Edges.md) for design rationale.

## Commands

```bash
pnpm build       # Build with tsdown
pnpm test        # Run tests
pnpm typecheck   # Type-check
```
