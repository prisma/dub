import { createHash } from 'node:crypto';
import { canonicalizeJson } from './canonicalize-json';
import { readMigrationPackage, writeMigrationManifest } from './io';
import type { MigrationManifest, MigrationOps } from './types';

export interface VerifyResult {
  readonly ok: boolean;
  readonly reason?: 'draft' | 'mismatch';
  readonly storedMigrationId?: string;
  readonly computedMigrationId?: string;
}

function sha256Hex(input: string): string {
  return createHash('sha256').update(input).digest('hex');
}

/**
 * Content-addressed migration identity over (manifest envelope sans
 * contracts/hints, ops). See ADR 199 "Storage-only migration identity"
 * for the rationale: contracts are anchored separately by the
 * storage-hash bookends inside the envelope; planner hints are advisory
 * and must not affect identity.
 */
export function computeMigrationId(manifest: MigrationManifest, ops: MigrationOps): string {
  const {
    migrationId: _migrationId,
    signature: _signature,
    fromContract: _fromContract,
    toContract: _toContract,
    hints: _hints,
    ...strippedMeta
  } = manifest;

  const canonicalManifest = canonicalizeJson(strippedMeta);
  const canonicalOps = canonicalizeJson(ops);

  const partHashes = [canonicalManifest, canonicalOps].map(sha256Hex);
  const hash = sha256Hex(canonicalizeJson(partHashes));

  return `sha256:${hash}`;
}

/** Compute and persist `migrationId` to `manifest.json`. */
export async function attestMigration(dir: string): Promise<string> {
  const pkg = await readMigrationPackage(dir);
  const migrationId = computeMigrationId(pkg.manifest, pkg.ops);

  const updated = { ...pkg.manifest, migrationId };
  await writeMigrationManifest(dir, updated);

  return migrationId;
}

export async function verifyMigration(dir: string): Promise<VerifyResult> {
  const pkg = await readMigrationPackage(dir);

  if (pkg.manifest.migrationId === null) {
    return { ok: false, reason: 'draft' };
  }

  const computed = computeMigrationId(pkg.manifest, pkg.ops);

  if (pkg.manifest.migrationId === computed) {
    return { ok: true, storedMigrationId: pkg.manifest.migrationId, computedMigrationId: computed };
  }

  return {
    ok: false,
    reason: 'mismatch',
    storedMigrationId: pkg.manifest.migrationId,
    computedMigrationId: computed,
  };
}
