import type {
  ControlAdapterInstance,
  ControlDriverInstance,
} from '@prisma-next/framework-components/control';
import type { SqlSchemaIR } from '@prisma-next/sql-schema-ir/types';
import type { DefaultNormalizer, NativeTypeNormalizer } from './schema-verify/verify-sql-schema';

/**
 * SQL control adapter interface for control-plane operations.
 * Implemented by target-specific adapters (e.g., Postgres, MySQL).
 *
 * @template TTarget - The target ID (e.g., 'postgres', 'mysql')
 */
export interface SqlControlAdapter<TTarget extends string = string>
  extends ControlAdapterInstance<'sql', TTarget> {
  /**
   * Introspects a database schema and returns a raw SqlSchemaIR.
   *
   * This is a pure schema discovery operation that queries the database catalog
   * and returns the schema structure without type mapping or contract enrichment.
   * Type mapping and enrichment are handled separately by enrichment helpers.
   *
   * @param driver - ControlDriverInstance instance for executing queries (target-specific)
   * @param contract - Optional contract for contract-guided introspection (filtering, optimization)
   * @param schema - Schema name to introspect (defaults to 'public')
   * @returns Promise resolving to SqlSchemaIR representing the live database schema
   */
  introspect(
    driver: ControlDriverInstance<'sql', TTarget>,
    contract?: unknown,
    schema?: string,
  ): Promise<SqlSchemaIR>;

  /**
   * Optional target-specific normalizer for raw database default expressions.
   * When provided, schema defaults (raw strings) are normalized before comparison
   * with contract defaults (ColumnDefault objects) during schema verification.
   */
  readonly normalizeDefault?: DefaultNormalizer;

  /**
   * Optional target-specific normalizer for schema native type names.
   * When provided, schema native types (from introspection) are normalized
   * before comparison with contract native types during schema verification.
   */
  readonly normalizeNativeType?: NativeTypeNormalizer;
}

/**
 * SQL control adapter descriptor interface.
 * Provides a factory method to create control adapter instances.
 *
 * @template TTarget - The target ID (e.g., 'postgres', 'mysql')
 */
export interface SqlControlAdapterDescriptor<TTarget extends string = string> {
  /**
   * Creates a SQL control adapter instance for control-plane operations.
   */
  create(): SqlControlAdapter<TTarget>;
}
