import { APP_SPACE_ID } from '@prisma-next/framework-components/control';

export { APP_SPACE_ID };

export interface SqlStatement {
  readonly sql: string;
  readonly params: readonly unknown[];
}

export const ensurePrismaContractSchemaStatement: SqlStatement = {
  sql: 'create schema if not exists prisma_contract',
  params: [],
};

/**
 * Schema for `prisma_contract.marker`. The `space text` primary key
 * supports one row per loaded contract space (`'app'`,
 * `'<extension-id>'`, …); on a brand-new database `CREATE TABLE IF NOT
 * EXISTS` produces this shape directly. The migration runner detects
 * pre-1.0 single-row markers (no `space` column) at boot and fails with
 * a structured `LEGACY_MARKER_SHAPE` error rather than auto-migrating —
 * see `specs/framework-mechanism.spec.md § 2`.
 */
export const ensureMarkerTableStatement: SqlStatement = {
  sql: `create table if not exists prisma_contract.marker (
    space text not null primary key default '${APP_SPACE_ID}',
    core_hash text not null,
    profile_hash text not null,
    contract_json jsonb,
    canonical_version int,
    updated_at timestamptz not null default now(),
    app_tag text,
    meta jsonb not null default '{}',
    invariants text[] not null default '{}'
  )`,
  params: [],
};

export const ensureLedgerTableStatement: SqlStatement = {
  sql: `create table if not exists prisma_contract.ledger (
    id bigserial primary key,
    created_at timestamptz not null default now(),
    origin_core_hash text,
    origin_profile_hash text,
    destination_core_hash text not null,
    destination_profile_hash text,
    contract_json_before jsonb,
    contract_json_after jsonb,
    operations jsonb not null
  )`,
  params: [],
};

export interface MergeMarkerInput {
  /**
   * Logical space identifier for this marker row. Required at every
   * call site so the type system surfaces every place that needs to
   * thread the value (rather than letting an `?? APP_SPACE_ID`
   * fall-through silently collapse multi-space markers onto the
   * `'app'` row). App-plan callers pass {@link APP_SPACE_ID}
   * (`'app'`); per-extension callers (planner / runner / verifier
   * extensions over contract spaces) pass the extension's space id.
   */
  readonly space: string;
  readonly storageHash: string;
  readonly profileHash: string;
  readonly contractJson?: unknown;
  readonly canonicalVersion?: number | null;
  readonly appTag?: string | null;
  readonly meta?: Record<string, unknown>;
  /**
   * Invariants to merge into `marker.invariants`. INSERT writes them as
   * the initial value (callers are expected to pass a sorted, deduped
   * array). UPDATE merges them with the existing column server-side via
   * a single atomic SQL expression.
   */
  readonly invariants: readonly string[];
}

export function buildMergeMarkerStatements(input: MergeMarkerInput): {
  readonly insert: SqlStatement;
  readonly update: SqlStatement;
} {
  const params: readonly unknown[] = [
    input.space,
    input.storageHash,
    input.profileHash,
    jsonParam(input.contractJson),
    input.canonicalVersion ?? null,
    input.appTag ?? null,
    jsonParam(input.meta ?? {}),
    input.invariants,
  ];

  return {
    insert: {
      sql: `insert into prisma_contract.marker (
        space,
        core_hash,
        profile_hash,
        contract_json,
        canonical_version,
        updated_at,
        app_tag,
        meta,
        invariants
      ) values (
        $1,
        $2,
        $3,
        $4::jsonb,
        $5,
        now(),
        $6,
        $7::jsonb,
        $8::text[]
      )`,
      params,
    },
    update: {
      // `invariants = array(select distinct unnest(invariants || $8::text[]) order by 1)`
      // reads the current column value under the UPDATE's row lock, unions
      // with the incoming array, dedupes, and sorts ascending — single
      // statement, atomic, no read-then-write window.
      sql: `update prisma_contract.marker set
        core_hash = $2,
        profile_hash = $3,
        contract_json = $4::jsonb,
        canonical_version = $5,
        updated_at = now(),
        app_tag = $6,
        meta = $7::jsonb,
        invariants = array(select distinct unnest(invariants || $8::text[]) order by 1)
      where space = $1`,
      params,
    },
  };
}

export interface LedgerInsertInput {
  readonly originStorageHash?: string | null;
  readonly originProfileHash?: string | null;
  readonly destinationStorageHash: string;
  readonly destinationProfileHash?: string | null;
  readonly contractJsonBefore?: unknown;
  readonly contractJsonAfter?: unknown;
  readonly operations: unknown;
}

export function buildLedgerInsertStatement(input: LedgerInsertInput): SqlStatement {
  return {
    sql: `insert into prisma_contract.ledger (
      origin_core_hash,
      origin_profile_hash,
      destination_core_hash,
      destination_profile_hash,
      contract_json_before,
      contract_json_after,
      operations
    ) values (
      $1,
      $2,
      $3,
      $4,
      $5::jsonb,
      $6::jsonb,
      $7::jsonb
    )`,
    params: [
      input.originStorageHash ?? null,
      input.originProfileHash ?? null,
      input.destinationStorageHash,
      input.destinationProfileHash ?? null,
      jsonParam(input.contractJsonBefore),
      jsonParam(input.contractJsonAfter),
      jsonParam(input.operations),
    ],
  };
}

function jsonParam(value: unknown): string {
  return JSON.stringify(value ?? null);
}
