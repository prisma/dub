/**
 * Unified codec definitions for Postgres adapter.
 *
 * This file contains a single source of truth for all codec information:
 * - Scalar names
 * - Type IDs
 * - Codec implementations (runtime)
 * - Type information (compile-time)
 *
 * This structure is used both at runtime (to populate the registry) and
 * at compile time (to derive CodecTypes).
 */

import type { JsonValue } from '@prisma-next/contract/types';
import type { Codec, CodecMeta, CodecTrait } from '@prisma-next/sql-relational-core/ast';
import { codec, defineCodecs, sqlCodecDefinitions } from '@prisma-next/sql-relational-core/ast';
import { ifDefined } from '@prisma-next/utils/defined';
import { type as arktype } from 'arktype';
import {
  PG_BIT_CODEC_ID,
  PG_BOOL_CODEC_ID,
  PG_CHAR_CODEC_ID,
  PG_ENUM_CODEC_ID,
  PG_FLOAT_CODEC_ID,
  PG_FLOAT4_CODEC_ID,
  PG_FLOAT8_CODEC_ID,
  PG_INT_CODEC_ID,
  PG_INT2_CODEC_ID,
  PG_INT4_CODEC_ID,
  PG_INT8_CODEC_ID,
  PG_INTERVAL_CODEC_ID,
  PG_JSON_CODEC_ID,
  PG_JSONB_CODEC_ID,
  PG_NUMERIC_CODEC_ID,
  PG_TEXT_CODEC_ID,
  PG_TIME_CODEC_ID,
  PG_TIMESTAMP_CODEC_ID,
  PG_TIMESTAMPTZ_CODEC_ID,
  PG_TIMETZ_CODEC_ID,
  PG_VARBIT_CODEC_ID,
  PG_VARCHAR_CODEC_ID,
} from './codec-ids';

const lengthParamsSchema = arktype({
  length: 'number.integer > 0',
});

const numericParamsSchema = arktype({
  precision: 'number.integer > 0 & number.integer <= 1000',
  'scale?': 'number.integer >= 0',
});

const precisionParamsSchema = arktype({
  'precision?': 'number.integer >= 0 & number.integer <= 6',
});

function renderLength(typeName: string, typeParams: Record<string, unknown>): string | undefined {
  const length = typeParams['length'];
  if (length === undefined) {
    return undefined;
  }
  if (typeof length !== 'number' || !Number.isFinite(length) || !Number.isInteger(length)) {
    throw new Error(
      `renderOutputType: expected integer "length" in typeParams for ${typeName}, got ${String(length)}`,
    );
  }
  return `${typeName}<${length}>`;
}

function renderPrecision(typeName: string, typeParams: Record<string, unknown>): string {
  const precision = typeParams['precision'];
  if (precision === undefined) {
    return typeName;
  }
  if (
    typeof precision !== 'number' ||
    !Number.isFinite(precision) ||
    !Number.isInteger(precision)
  ) {
    throw new Error(
      `renderOutputType: expected integer "precision" in typeParams for ${typeName}, got ${String(precision)}`,
    );
  }
  return `${typeName}<${precision}>`;
}

// Phase C: postgres' raw json/jsonb codecs no longer carry a
// `renderOutputType` slot — the schema-typed JSON surface that drove
// `typeParams: { schemaJson, type? }` retired in favor of the per-library
// extension package (`@prisma-next/extension-arktype-json`). Untyped
// json/jsonb columns have no typeParams; the framework emit path falls
// through to the generic `CodecTypes['pg/jsonb@1']['output']` accessor
// (which resolves to `JsonValue` via the codec-types map).

function aliasCodec<
  Id extends string,
  TTraits extends readonly CodecTrait[],
  TWire,
  TJs,
  TParams,
  THelper,
>(
  base: Codec<string, TTraits, TWire, TJs, TParams, THelper>,
  options: {
    readonly typeId: Id;
    readonly targetTypes: readonly string[];
    readonly meta?: CodecMeta;
  },
): Codec<Id, TTraits, TWire, TJs, TParams, THelper> {
  return {
    id: options.typeId,
    targetTypes: options.targetTypes,
    ...ifDefined('meta', options.meta),
    ...ifDefined('paramsSchema', base.paramsSchema),
    ...ifDefined('init', base.init),
    ...ifDefined('encode', base.encode),
    ...ifDefined('traits', base.traits),
    ...ifDefined('renderOutputType', base.renderOutputType),
    decode: base.decode,
    encodeJson: base.encodeJson,
    decodeJson: base.decodeJson,
  } as Codec<Id, TTraits, TWire, TJs, TParams, THelper>;
}

const sqlCharCodec = sqlCodecDefinitions.char.codec;
const sqlVarcharCodec = sqlCodecDefinitions.varchar.codec;
const sqlIntCodec = sqlCodecDefinitions.int.codec;
const sqlFloatCodec = sqlCodecDefinitions.float.codec;
const sqlTextCodec = sqlCodecDefinitions.text.codec;
const sqlTimestampCodec = sqlCodecDefinitions.timestamp.codec;

// Create individual codec instances
const pgTextCodec = codec({
  typeId: PG_TEXT_CODEC_ID,
  targetTypes: ['text'],
  traits: ['equality', 'order', 'textual'],
  encode: (value: string): string => value,
  decode: (wire: string): string => wire,
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'text',
        },
      },
    },
  },
});

const pgCharCodec = aliasCodec(sqlCharCodec, {
  typeId: PG_CHAR_CODEC_ID,
  targetTypes: ['character'],
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'character',
        },
      },
    },
  },
});

const pgVarcharCodec = aliasCodec(sqlVarcharCodec, {
  typeId: PG_VARCHAR_CODEC_ID,
  targetTypes: ['character varying'],
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'character varying',
        },
      },
    },
  },
});

const pgIntCodec = aliasCodec(sqlIntCodec, {
  typeId: PG_INT_CODEC_ID,
  targetTypes: ['int4'],
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'integer',
        },
      },
    },
  },
});

const pgFloatCodec = aliasCodec(sqlFloatCodec, {
  typeId: PG_FLOAT_CODEC_ID,
  targetTypes: ['float8'],
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'double precision',
        },
      },
    },
  },
});

const pgInt4Codec = codec({
  typeId: PG_INT4_CODEC_ID,
  targetTypes: ['int4'],
  traits: ['equality', 'order', 'numeric'],
  encode: (value: number): number => value,
  decode: (wire: number): number => wire,
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'integer',
        },
      },
    },
  },
});

const pgNumericCodec = codec<
  typeof PG_NUMERIC_CODEC_ID,
  readonly ['equality', 'order', 'numeric'],
  string,
  string
>({
  typeId: PG_NUMERIC_CODEC_ID,
  targetTypes: ['numeric', 'decimal'],
  traits: ['equality', 'order', 'numeric'],
  encode: (value: string): string => value,
  decode: (wire: string | number): string => {
    if (typeof wire === 'number') return String(wire);
    return wire;
  },
  paramsSchema: numericParamsSchema,
  renderOutputType: (typeParams) => {
    const precision = typeParams['precision'];
    if (precision === undefined) return undefined;
    if (
      typeof precision !== 'number' ||
      !Number.isFinite(precision) ||
      !Number.isInteger(precision)
    ) {
      throw new Error(
        `renderOutputType: expected integer "precision" in typeParams for Numeric, got ${String(precision)}`,
      );
    }
    const scale = typeParams['scale'];
    return typeof scale === 'number' ? `Numeric<${precision}, ${scale}>` : `Numeric<${precision}>`;
  },
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'numeric',
        },
      },
    },
  },
});

const pgInt2Codec = codec({
  typeId: PG_INT2_CODEC_ID,
  targetTypes: ['int2'],
  traits: ['equality', 'order', 'numeric'],
  encode: (value: number): number => value,
  decode: (wire: number): number => wire,
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'smallint',
        },
      },
    },
  },
});

const pgInt8Codec = codec({
  typeId: PG_INT8_CODEC_ID,
  targetTypes: ['int8'],
  traits: ['equality', 'order', 'numeric'],
  encode: (value: number): number => value,
  decode: (wire: number): number => wire,
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'bigint',
        },
      },
    },
  },
});

const pgFloat4Codec = codec({
  typeId: PG_FLOAT4_CODEC_ID,
  targetTypes: ['float4'],
  traits: ['equality', 'order', 'numeric'],
  encode: (value: number): number => value,
  decode: (wire: number): number => wire,
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'real',
        },
      },
    },
  },
});

const pgFloat8Codec = codec({
  typeId: PG_FLOAT8_CODEC_ID,
  targetTypes: ['float8'],
  traits: ['equality', 'order', 'numeric'],
  encode: (value: number): number => value,
  decode: (wire: number): number => wire,
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'double precision',
        },
      },
    },
  },
});

const pgTimestampCodec = codec<
  typeof PG_TIMESTAMP_CODEC_ID,
  readonly ['equality', 'order'],
  Date,
  Date
>({
  typeId: PG_TIMESTAMP_CODEC_ID,
  targetTypes: ['timestamp'],
  traits: ['equality', 'order'],
  encode: (value: Date): Date => value,
  decode: (wire: Date): Date => wire,
  encodeJson: (value: Date) => value.toISOString(),
  decodeJson: (json) => {
    if (typeof json !== 'string') {
      throw new Error(`Expected ISO date string for pg/timestamp@1, got ${typeof json}`);
    }
    const date = new Date(json);
    if (Number.isNaN(date.getTime())) {
      throw new Error(`Invalid ISO date string for pg/timestamp@1: ${json}`);
    }
    return date;
  },
  paramsSchema: precisionParamsSchema,
  renderOutputType: (typeParams) => renderPrecision('Timestamp', typeParams),
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'timestamp without time zone',
        },
      },
    },
  },
});

const pgTimestamptzCodec = codec<
  typeof PG_TIMESTAMPTZ_CODEC_ID,
  readonly ['equality', 'order'],
  Date,
  Date
>({
  typeId: PG_TIMESTAMPTZ_CODEC_ID,
  targetTypes: ['timestamptz'],
  traits: ['equality', 'order'],
  encode: (value: Date): Date => value,
  decode: (wire: Date): Date => wire,
  encodeJson: (value: Date) => value.toISOString(),
  decodeJson: (json) => {
    if (typeof json !== 'string') {
      throw new Error(`Expected ISO date string for pg/timestamptz@1, got ${typeof json}`);
    }
    const date = new Date(json);
    if (Number.isNaN(date.getTime())) {
      throw new Error(`Invalid ISO date string for pg/timestamptz@1: ${json}`);
    }
    return date;
  },
  paramsSchema: precisionParamsSchema,
  renderOutputType: (typeParams) => renderPrecision('Timestamptz', typeParams),
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'timestamp with time zone',
        },
      },
    },
  },
});

const pgTimeCodec = codec<typeof PG_TIME_CODEC_ID, readonly ['equality', 'order'], string, string>({
  typeId: PG_TIME_CODEC_ID,
  targetTypes: ['time'],
  traits: ['equality', 'order'],
  encode: (value: string): string => value,
  decode: (wire: string): string => wire,
  paramsSchema: precisionParamsSchema,
  renderOutputType: (typeParams) => renderPrecision('Time', typeParams),
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'time',
        },
      },
    },
  },
});

const pgTimetzCodec = codec<
  typeof PG_TIMETZ_CODEC_ID,
  readonly ['equality', 'order'],
  string,
  string
>({
  typeId: PG_TIMETZ_CODEC_ID,
  targetTypes: ['timetz'],
  traits: ['equality', 'order'],
  encode: (value: string): string => value,
  decode: (wire: string): string => wire,
  paramsSchema: precisionParamsSchema,
  renderOutputType: (typeParams) => renderPrecision('Timetz', typeParams),
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'timetz',
        },
      },
    },
  },
});

const pgBoolCodec = codec({
  typeId: PG_BOOL_CODEC_ID,
  targetTypes: ['bool'],
  traits: ['equality', 'boolean'],
  encode: (value: boolean): boolean => value,
  decode: (wire: boolean): boolean => wire,
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'boolean',
        },
      },
    },
  },
});

const pgBitCodec = codec<typeof PG_BIT_CODEC_ID, readonly ['equality', 'order'], string, string>({
  typeId: PG_BIT_CODEC_ID,
  targetTypes: ['bit'],
  traits: ['equality', 'order'],
  encode: (value: string): string => value,
  decode: (wire: string): string => wire,
  paramsSchema: lengthParamsSchema,
  renderOutputType: (typeParams) => renderLength('Bit', typeParams),
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'bit',
        },
      },
    },
  },
});

const pgVarbitCodec = codec<
  typeof PG_VARBIT_CODEC_ID,
  readonly ['equality', 'order'],
  string,
  string
>({
  typeId: PG_VARBIT_CODEC_ID,
  targetTypes: ['bit varying'],
  traits: ['equality', 'order'],
  encode: (value: string): string => value,
  decode: (wire: string): string => wire,
  paramsSchema: lengthParamsSchema,
  renderOutputType: (typeParams) => renderLength('VarBit', typeParams),
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'bit varying',
        },
      },
    },
  },
});

const pgEnumCodec = codec({
  typeId: PG_ENUM_CODEC_ID,
  targetTypes: ['enum'],
  traits: ['equality', 'order'],
  encode: (value: string): string => value,
  decode: (wire: string): string => wire,
  renderOutputType: (typeParams) => {
    const values = typeParams['values'];
    if (!Array.isArray(values)) {
      throw new Error(
        `renderOutputType: expected array "values" in typeParams for enum, got ${typeof values}`,
      );
    }
    return values
      .map((value) => `'${String(value).replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`)
      .join(' | ');
  },
});

const pgIntervalCodec = codec<
  typeof PG_INTERVAL_CODEC_ID,
  readonly ['equality', 'order'],
  string | Record<string, unknown>,
  string
>({
  typeId: PG_INTERVAL_CODEC_ID,
  targetTypes: ['interval'],
  traits: ['equality', 'order'],
  encode: (value: string): string => value,
  decode: (wire: string | Record<string, unknown>): string => {
    if (typeof wire === 'string') return wire;
    return JSON.stringify(wire);
  },
  paramsSchema: precisionParamsSchema,
  renderOutputType: (typeParams) => renderPrecision('Interval', typeParams),
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'interval',
        },
      },
    },
  },
});

const pgJsonCodec = codec({
  typeId: PG_JSON_CODEC_ID,
  targetTypes: ['json'],
  traits: [],
  encode: (value: string | JsonValue): string => JSON.stringify(value),
  decode: (wire: string | JsonValue): JsonValue =>
    typeof wire === 'string' ? JSON.parse(wire) : wire,
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'json',
        },
      },
    },
  },
});

const pgJsonbCodec = codec({
  typeId: PG_JSONB_CODEC_ID,
  targetTypes: ['jsonb'],
  traits: ['equality'],
  encode: (value: string | JsonValue): string => JSON.stringify(value),
  decode: (wire: string | JsonValue): JsonValue =>
    typeof wire === 'string' ? JSON.parse(wire) : wire,
  meta: {
    db: {
      sql: {
        postgres: {
          nativeType: 'jsonb',
        },
      },
    },
  },
});

// Build codec definitions using the builder DSL
const codecs = defineCodecs()
  .add('char', sqlCharCodec)
  .add('varchar', sqlVarcharCodec)
  .add('int', sqlIntCodec)
  .add('float', sqlFloatCodec)
  .add('sql-text', sqlTextCodec)
  .add('sql-timestamp', sqlTimestampCodec)
  .add('text', pgTextCodec)
  .add('character', pgCharCodec)
  .add('character varying', pgVarcharCodec)
  .add('integer', pgIntCodec)
  .add('double precision', pgFloatCodec)
  .add('int4', pgInt4Codec)
  .add('int2', pgInt2Codec)
  .add('int8', pgInt8Codec)
  .add('float4', pgFloat4Codec)
  .add('float8', pgFloat8Codec)
  .add('numeric', pgNumericCodec)
  .add('timestamp', pgTimestampCodec)
  .add('timestamptz', pgTimestamptzCodec)
  .add('time', pgTimeCodec)
  .add('timetz', pgTimetzCodec)
  .add('bool', pgBoolCodec)
  .add('bit', pgBitCodec)
  .add('bit varying', pgVarbitCodec)
  .add('interval', pgIntervalCodec)
  .add('enum', pgEnumCodec)
  .add('json', pgJsonCodec)
  .add('jsonb', pgJsonbCodec);

// Export derived structures directly from codecs builder
export const codecDefinitions = codecs.codecDefinitions;
export const dataTypes = codecs.dataTypes;

export type CodecTypes = typeof codecs.CodecTypes;
