import type { ContractMarkerRecord } from '@prisma-next/contract/types';
import type {
  MigrationOperationPolicy,
  SqlControlFamilyInstance,
  SqlMigrationPlanContractInfo,
  SqlMigrationPlanOperation,
  SqlMigrationPlanOperationStep,
  SqlMigrationRunner,
  SqlMigrationRunnerExecuteOptions,
  SqlMigrationRunnerFailure,
  SqlMigrationRunnerResult,
} from '@prisma-next/family-sql/control';
import { runnerFailure, runnerSuccess } from '@prisma-next/family-sql/control';
import { verifySqlSchema } from '@prisma-next/family-sql/schema-verify';
import type { DataTransformOperation } from '@prisma-next/framework-components/control';
import { SqlQueryError } from '@prisma-next/sql-errors';
import { ifDefined } from '@prisma-next/utils/defined';
import type { Result } from '@prisma-next/utils/result';
import { ok, okVoid } from '@prisma-next/utils/result';
import { parsePostgresDefault } from '../default-normalizer';
import { normalizeSchemaNativeType } from '../native-type-normalizer';
import type { PostgresPlanTargetDetails } from './planner-target-details';
import {
  buildLedgerInsertStatement,
  buildMergeMarkerStatements,
  ensureLedgerTableStatement,
  ensureMarkerTableStatement,
  ensurePrismaContractSchemaStatement,
  type SqlStatement,
} from './statement-builders';

interface RunnerConfig {
  readonly defaultSchema: string;
}

interface ApplyPlanSuccessValue {
  readonly operationsExecuted: number;
  readonly executedOperations: readonly SqlMigrationPlanOperation<PostgresPlanTargetDetails>[];
}

const DEFAULT_CONFIG: RunnerConfig = {
  defaultSchema: 'public',
};

const LOCK_DOMAIN = 'prisma_next.contract.marker';

function isDataTransformOperation(op: unknown): op is DataTransformOperation {
  return (
    typeof op === 'object' &&
    op !== null &&
    'operationClass' in op &&
    (op as { operationClass: string }).operationClass === 'data' &&
    'name' in op &&
    'check' in op &&
    'run' in op
  );
}

/**
 * Deep clones and freezes a record object to prevent mutation.
 * Recursively clones nested objects and arrays to ensure complete isolation.
 */
function cloneAndFreezeRecord<T extends Record<string, unknown>>(value: T): T {
  const cloned: Record<string, unknown> = {};
  for (const [key, val] of Object.entries(value)) {
    if (val === null || val === undefined) {
      cloned[key] = val;
    } else if (Array.isArray(val)) {
      // Clone array (shallow clone of array elements)
      cloned[key] = Object.freeze([...val]);
    } else if (typeof val === 'object') {
      // Recursively clone nested objects
      cloned[key] = cloneAndFreezeRecord(val as Record<string, unknown>);
    } else {
      // Primitives are copied as-is
      cloned[key] = val;
    }
  }
  return Object.freeze(cloned) as T;
}

export function createPostgresMigrationRunner(
  family: SqlControlFamilyInstance,
  config: Partial<RunnerConfig> = {},
): SqlMigrationRunner<PostgresPlanTargetDetails> {
  return new PostgresMigrationRunner(family, { ...DEFAULT_CONFIG, ...config });
}

class PostgresMigrationRunner implements SqlMigrationRunner<PostgresPlanTargetDetails> {
  constructor(
    private readonly family: SqlControlFamilyInstance,
    private readonly config: RunnerConfig,
  ) {}

  async execute(
    options: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>,
  ): Promise<SqlMigrationRunnerResult> {
    const schema = options.schemaName ?? this.config.defaultSchema;
    const driver = options.driver;
    const lockKey = `${LOCK_DOMAIN}:${schema}`;

    // Static checks - fail fast before transaction
    const destinationCheck = this.ensurePlanMatchesDestinationContract(
      options.plan.destination,
      options.destinationContract,
    );
    if (!destinationCheck.ok) {
      return destinationCheck;
    }

    const policyCheck = this.enforcePolicyCompatibility(options.policy, options.plan.operations);
    if (!policyCheck.ok) {
      return policyCheck;
    }

    // Begin transaction for DB operations
    await this.beginTransaction(driver);
    let committed = false;
    try {
      await this.acquireLock(driver, lockKey);
      await this.ensureControlTables(driver);
      const existingMarker = await this.family.readMarker({ driver });

      // Validate plan origin matches existing marker (needs marker from DB)
      const markerCheck = this.ensureMarkerCompatibility(existingMarker, options.plan);
      if (!markerCheck.ok) {
        return markerCheck;
      }

      // db update (origin: null) always applies; migration-apply (origin set,
      // origin !== destination) skips if marker already matches destination.
      // Self-edges (origin === destination) intentionally bypass the skip:
      // the migration is data-only, and the data transform's own check
      // decides whether `run` fires.
      const markerAtDestination = this.markerMatchesDestination(existingMarker, options.plan);
      const isSelfEdge = options.plan.origin?.storageHash === options.plan.destination.storageHash;
      const skipOperations = markerAtDestination && options.plan.origin != null && !isSelfEdge;
      let applyValue: ApplyPlanSuccessValue;

      if (skipOperations) {
        applyValue = { operationsExecuted: 0, executedOperations: [] };
      } else {
        const applyResult = await this.applyPlan(driver, options);
        if (!applyResult.ok) {
          return applyResult;
        }
        applyValue = applyResult.value;
      }

      // Verify resulting schema matches contract
      // Step 1: Introspect live schema (DB I/O, family-owned)
      const schemaIR = await this.family.introspect({
        driver,
        contract: options.destinationContract,
      });

      // Step 2: Pure verification (no DB I/O)
      const schemaVerifyResult = verifySqlSchema({
        contract: options.destinationContract,
        schema: schemaIR,
        strict: options.strictVerification ?? true,
        context: options.context ?? {},
        typeMetadataRegistry: this.family.typeMetadataRegistry,
        frameworkComponents: options.frameworkComponents,
        normalizeDefault: parsePostgresDefault,
        normalizeNativeType: normalizeSchemaNativeType,
      });
      if (!schemaVerifyResult.ok) {
        return runnerFailure('SCHEMA_VERIFY_FAILED', schemaVerifyResult.summary, {
          why: 'The resulting database schema does not satisfy the destination contract.',
          meta: {
            issues: schemaVerifyResult.schema.issues,
          },
        });
      }

      // Self-edge no-op detection: a self-edge migration with zero ops in
      // the plan that brings no new invariants produced no observable
      // change. Skip the marker + ledger writes so an idempotent re-apply
      // of a self-edge data transform doesn't churn updatedAt or pile up
      // empty ledger entries. db update no-ops still write a ledger entry
      // as audit trail.
      //
      // TODO(invariant-routing follow-up): `executeDataTransform` always
      // counts every op it visits (including self-skips via `check === true`
      // or empty idempotency probe), so `operationsExecuted === 0` here
      // means "the plan had zero ops" rather than "every op self-skipped".
      // The CLI is unaffected today because `migration-apply.ts` marker-
      // subtraction empties `effectiveRequired` first and short-circuits
      // before we run; the non-CLI re-apply path needs a per-op `executed`
      // flag threaded through `executeDataTransform` to recover the
      // intended check. See review thread A13 / future M5 ADR draft.
      const incomingInvariants = options.plan.providedInvariants;
      const existingInvariants = new Set(existingMarker?.invariants ?? []);
      const incomingIsSubsetOfExisting = incomingInvariants.every((id) =>
        existingInvariants.has(id),
      );
      const isSelfEdgeNoOp =
        isSelfEdge && applyValue.operationsExecuted === 0 && incomingIsSubsetOfExisting;

      if (!isSelfEdgeNoOp) {
        await this.upsertMarker(driver, options, existingMarker);
        await this.recordLedgerEntry(
          driver,
          options,
          existingMarker,
          applyValue.executedOperations,
        );
      }

      await this.commitTransaction(driver);
      committed = true;
      return runnerSuccess({
        operationsPlanned: options.plan.operations.length,
        operationsExecuted: applyValue.operationsExecuted,
      });
    } finally {
      if (!committed) {
        await this.rollbackTransaction(driver);
      }
    }
  }

  private async applyPlan(
    driver: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['driver'],
    options: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>,
  ): Promise<Result<ApplyPlanSuccessValue, SqlMigrationRunnerFailure>> {
    const checks = options.executionChecks;
    const runPrechecks = checks?.prechecks !== false; // Default true
    const runPostchecks = checks?.postchecks !== false; // Default true
    const runIdempotency = checks?.idempotencyChecks !== false; // Default true

    let operationsExecuted = 0;
    const executedOperations: Array<SqlMigrationPlanOperation<PostgresPlanTargetDetails>> = [];
    for (const operation of options.plan.operations) {
      options.callbacks?.onOperationStart?.(operation);
      try {
        // Data transform operations have a different execution lifecycle
        if (operation.operationClass === 'data' && isDataTransformOperation(operation)) {
          const dtResult = await this.executeDataTransform(driver, operation, {
            runIdempotency,
          });
          if (!dtResult.ok) {
            return dtResult;
          }
          executedOperations.push(operation);
          operationsExecuted += 1;
          continue;
        }

        // Idempotency probe: only run if both postchecks and idempotency checks are enabled
        if (runPostchecks && runIdempotency) {
          const postcheckAlreadySatisfied = await this.expectationsAreSatisfied(
            driver,
            operation.postcheck,
          );
          if (postcheckAlreadySatisfied) {
            executedOperations.push(this.createPostcheckPreSatisfiedSkipRecord(operation));
            continue;
          }
        }

        // Prechecks: only run if enabled
        if (runPrechecks) {
          const precheckResult = await this.runExpectationSteps(
            driver,
            operation.precheck,
            operation,
            'precheck',
          );
          if (!precheckResult.ok) {
            return precheckResult;
          }
        }

        const executeResult = await this.runExecuteSteps(driver, operation.execute, operation);
        if (!executeResult.ok) {
          return executeResult;
        }

        // Postchecks: only run if enabled
        if (runPostchecks) {
          const postcheckResult = await this.runExpectationSteps(
            driver,
            operation.postcheck,
            operation,
            'postcheck',
          );
          if (!postcheckResult.ok) {
            return postcheckResult;
          }
        }

        executedOperations.push(operation);
        operationsExecuted += 1;
      } finally {
        options.callbacks?.onOperationComplete?.(operation);
      }
    }
    return ok({ operationsExecuted, executedOperations });
  }

  /**
   * Executes a data transform operation with the check → (skip or run) → check lifecycle.
   *
   * 1. If check is a query AST: render to SQL, execute. Empty result = already applied (skip).
   * 2. If check is `true`: always skip. If `false`: always run.
   * 3. Execute run ASTs (rendered to SQL) sequentially.
   * 4. Re-execute check as post-run validation. If violations remain, fail.
   */
  private async executeDataTransform(
    driver: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['driver'],
    op: DataTransformOperation,
    options: { runIdempotency: boolean },
  ): Promise<Result<void, SqlMigrationRunnerFailure>> {
    // Step 1: Check (skip guard)
    if (op.check === true) {
      // Always skip, regardless of idempotency setting
      return okVoid();
    }
    if (options.runIdempotency && op.check !== null && op.check !== false) {
      const checkResult = await driver.query(op.check.sql, op.check.params);
      if (checkResult.rows.length === 0) {
        // No violations — already applied, skip
        return okVoid();
      }
    }

    // Step 2: Execute run steps
    if (op.run) {
      for (const plan of op.run) {
        try {
          await driver.query(plan.sql, plan.params);
        } catch (error: unknown) {
          if (SqlQueryError.is(error)) {
            return runnerFailure(
              'EXECUTION_FAILED',
              `Data transform "${op.name}" failed: ${error.message}`,
              {
                why: error.message,
                meta: {
                  operationId: op.id,
                  dataTransformName: op.name,
                  sql: plan.sql,
                  sqlState: error.sqlState,
                },
              },
            );
          }
          throw error;
        }
      }
    }

    // Step 3: Post-run validation (check again)
    if (op.check !== null && op.check !== false) {
      const checkResult = await driver.query(op.check.sql, op.check.params);
      if (checkResult.rows.length > 0) {
        return runnerFailure(
          'POSTCHECK_FAILED',
          `Data transform "${op.name}" did not resolve all violations (${checkResult.rows.length} remaining)`,
          {
            why: `After executing the data transform, the check query still returns ${checkResult.rows.length} violation(s).`,
            meta: {
              operationId: op.id,
              dataTransformName: op.name,
              remainingViolations: checkResult.rows.length,
            },
          },
        );
      }
    }

    return okVoid();
  }

  private async ensureControlTables(
    driver: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['driver'],
  ): Promise<void> {
    await this.executeStatement(driver, ensurePrismaContractSchemaStatement);
    await this.executeStatement(driver, ensureMarkerTableStatement);
    await this.executeStatement(driver, ensureLedgerTableStatement);
  }

  private async runExpectationSteps(
    driver: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['driver'],
    steps: readonly SqlMigrationPlanOperationStep[],
    operation: SqlMigrationPlanOperation<PostgresPlanTargetDetails>,
    phase: 'precheck' | 'postcheck',
  ): Promise<Result<void, SqlMigrationRunnerFailure>> {
    for (const step of steps) {
      const result = await driver.query(step.sql);
      if (!this.stepResultIsTrue(result.rows)) {
        const code = phase === 'precheck' ? 'PRECHECK_FAILED' : 'POSTCHECK_FAILED';
        return runnerFailure(
          code,
          `Operation ${operation.id} failed during ${phase}: ${step.description}`,
          {
            meta: {
              operationId: operation.id,
              phase,
              stepDescription: step.description,
            },
          },
        );
      }
    }
    return okVoid();
  }

  private async runExecuteSteps(
    driver: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['driver'],
    steps: readonly SqlMigrationPlanOperationStep[],
    operation: SqlMigrationPlanOperation<PostgresPlanTargetDetails>,
  ): Promise<Result<void, SqlMigrationRunnerFailure>> {
    for (const step of steps) {
      try {
        await driver.query(step.sql);
      } catch (error: unknown) {
        // Catch SqlQueryError and include normalized metadata
        if (SqlQueryError.is(error)) {
          return runnerFailure(
            'EXECUTION_FAILED',
            `Operation ${operation.id} failed during execution: ${step.description}`,
            {
              why: error.message,
              meta: {
                operationId: operation.id,
                stepDescription: step.description,
                sql: step.sql,
                sqlState: error.sqlState,
                constraint: error.constraint,
                table: error.table,
                column: error.column,
                detail: error.detail,
              },
            },
          );
        }
        // Let SqlConnectionError and other errors propagate (fail-fast)
        throw error;
      }
    }
    return okVoid();
  }

  private stepResultIsTrue(rows: readonly Record<string, unknown>[]): boolean {
    if (!rows || rows.length === 0) {
      return false;
    }
    const firstRow = rows[0];
    const firstValue = firstRow ? Object.values(firstRow)[0] : undefined;
    if (typeof firstValue === 'boolean') {
      return firstValue;
    }
    if (typeof firstValue === 'number') {
      return firstValue !== 0;
    }
    if (typeof firstValue === 'string') {
      const lower = firstValue.toLowerCase();
      // PostgreSQL boolean representations: 't'/'f', 'true'/'false', '1'/'0'
      if (lower === 't' || lower === 'true' || lower === '1') {
        return true;
      }
      if (lower === 'f' || lower === 'false' || lower === '0') {
        return false;
      }
      // For other strings, non-empty is truthy (though this case shouldn't occur for boolean checks)
      return firstValue.length > 0;
    }
    return Boolean(firstValue);
  }

  private async expectationsAreSatisfied(
    driver: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['driver'],
    steps: readonly SqlMigrationPlanOperationStep[],
  ): Promise<boolean> {
    if (steps.length === 0) {
      return false;
    }
    for (const step of steps) {
      const result = await driver.query(step.sql);
      if (!this.stepResultIsTrue(result.rows)) {
        return false;
      }
    }
    return true;
  }

  private createPostcheckPreSatisfiedSkipRecord(
    operation: SqlMigrationPlanOperation<PostgresPlanTargetDetails>,
  ): SqlMigrationPlanOperation<PostgresPlanTargetDetails> {
    // Clone and freeze existing meta if present
    const clonedMeta = operation.meta ? cloneAndFreezeRecord(operation.meta) : undefined;

    // Create frozen runner metadata
    const runnerMeta = Object.freeze({
      skipped: true,
      reason: 'postcheck_pre_satisfied',
    });

    // Merge and freeze the combined meta
    const mergedMeta = Object.freeze({
      ...(clonedMeta ?? {}),
      runner: runnerMeta,
    });

    // Clone and freeze arrays to prevent mutation
    const frozenPostcheck = Object.freeze([...operation.postcheck]);

    return Object.freeze({
      id: operation.id,
      label: operation.label,
      ...ifDefined('summary', operation.summary),
      operationClass: operation.operationClass,
      target: operation.target, // Already frozen from plan creation
      precheck: Object.freeze([]),
      execute: Object.freeze([]),
      postcheck: frozenPostcheck,
      ...ifDefined('meta', operation.meta || mergedMeta ? mergedMeta : undefined),
    });
  }

  private markerMatchesDestination(
    marker: ContractMarkerRecord | null,
    plan: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['plan'],
  ): boolean {
    if (!marker) {
      return false;
    }
    if (marker.storageHash !== plan.destination.storageHash) {
      return false;
    }
    if (plan.destination.profileHash && marker.profileHash !== plan.destination.profileHash) {
      return false;
    }
    return true;
  }

  private enforcePolicyCompatibility(
    policy: MigrationOperationPolicy,
    operations: readonly SqlMigrationPlanOperation<PostgresPlanTargetDetails>[],
  ): Result<void, SqlMigrationRunnerFailure> {
    const allowedClasses = new Set(policy.allowedOperationClasses);
    for (const operation of operations) {
      if (!allowedClasses.has(operation.operationClass)) {
        return runnerFailure(
          'POLICY_VIOLATION',
          `Operation ${operation.id} has class "${operation.operationClass}" which is not allowed by policy.`,
          {
            why: `Policy only allows: ${policy.allowedOperationClasses.join(', ')}.`,
            meta: {
              operationId: operation.id,
              operationClass: operation.operationClass,
              allowedClasses: policy.allowedOperationClasses,
            },
          },
        );
      }
    }
    return okVoid();
  }

  private ensureMarkerCompatibility(
    marker: ContractMarkerRecord | null,
    plan: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['plan'],
  ): Result<void, SqlMigrationRunnerFailure> {
    const origin = plan.origin ?? null;
    if (!origin) {
      // No origin assertion on the plan — the caller does not want origin validation.
      // This is the case for `db update`, which introspects the live schema and does not
      // rely on marker continuity. `db init` handles its own marker checks before the runner.
      return okVoid();
    }

    if (!marker) {
      return runnerFailure(
        'MARKER_ORIGIN_MISMATCH',
        `Missing contract marker: expected origin storage hash ${origin.storageHash}.`,
        {
          meta: {
            expectedOriginStorageHash: origin.storageHash,
          },
        },
      );
    }
    if (marker.storageHash !== origin.storageHash) {
      return runnerFailure(
        'MARKER_ORIGIN_MISMATCH',
        `Existing contract marker (${marker.storageHash}) does not match plan origin (${origin.storageHash}).`,
        {
          meta: {
            markerStorageHash: marker.storageHash,
            expectedOriginStorageHash: origin.storageHash,
          },
        },
      );
    }
    if (origin.profileHash && marker.profileHash !== origin.profileHash) {
      return runnerFailure(
        'MARKER_ORIGIN_MISMATCH',
        `Existing contract marker profile hash (${marker.profileHash}) does not match plan origin profile hash (${origin.profileHash}).`,
        {
          meta: {
            markerProfileHash: marker.profileHash,
            expectedOriginProfileHash: origin.profileHash,
          },
        },
      );
    }
    return okVoid();
  }

  private ensurePlanMatchesDestinationContract(
    destination: SqlMigrationPlanContractInfo,
    contract: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['destinationContract'],
  ): Result<void, SqlMigrationRunnerFailure> {
    if (destination.storageHash !== contract.storage.storageHash) {
      return runnerFailure(
        'DESTINATION_CONTRACT_MISMATCH',
        `Plan destination storage hash (${destination.storageHash}) does not match provided contract storage hash (${contract.storage.storageHash}).`,
        {
          meta: {
            planStorageHash: destination.storageHash,
            contractStorageHash: contract.storage.storageHash,
          },
        },
      );
    }
    if (
      destination.profileHash &&
      contract.profileHash &&
      destination.profileHash !== contract.profileHash
    ) {
      return runnerFailure(
        'DESTINATION_CONTRACT_MISMATCH',
        `Plan destination profile hash (${destination.profileHash}) does not match provided contract profile hash (${contract.profileHash}).`,
        {
          meta: {
            planProfileHash: destination.profileHash,
            contractProfileHash: contract.profileHash,
          },
        },
      );
    }
    return okVoid();
  }

  private async upsertMarker(
    driver: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['driver'],
    options: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>,
    existingMarker: ContractMarkerRecord | null,
  ): Promise<void> {
    const incomingInvariants = options.plan.providedInvariants;
    const writeStatements = buildMergeMarkerStatements({
      storageHash: options.plan.destination.storageHash,
      profileHash:
        options.plan.destination.profileHash ??
        options.destinationContract.profileHash ??
        options.plan.destination.storageHash,
      contractJson: options.destinationContract,
      canonicalVersion: null,
      meta: {},
      invariants: incomingInvariants,
    });
    const statement = existingMarker ? writeStatements.update : writeStatements.insert;
    await this.executeStatement(driver, statement);
  }

  private async recordLedgerEntry(
    driver: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['driver'],
    options: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>,
    existingMarker: ContractMarkerRecord | null,
    executedOperations: readonly SqlMigrationPlanOperation<PostgresPlanTargetDetails>[],
  ): Promise<void> {
    const ledgerStatement = buildLedgerInsertStatement({
      originStorageHash: existingMarker?.storageHash ?? null,
      originProfileHash: existingMarker?.profileHash ?? null,
      destinationStorageHash: options.plan.destination.storageHash,
      destinationProfileHash:
        options.plan.destination.profileHash ??
        options.destinationContract.profileHash ??
        options.plan.destination.storageHash,
      contractJsonBefore: existingMarker?.contractJson ?? null,
      contractJsonAfter: options.destinationContract,
      operations: executedOperations,
    });
    await this.executeStatement(driver, ledgerStatement);
  }

  private async acquireLock(
    driver: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['driver'],
    key: string,
  ): Promise<void> {
    await driver.query('select pg_advisory_xact_lock(hashtext($1))', [key]);
  }

  private async beginTransaction(
    driver: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['driver'],
  ): Promise<void> {
    await driver.query('BEGIN');
  }

  private async commitTransaction(
    driver: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['driver'],
  ): Promise<void> {
    await driver.query('COMMIT');
  }

  private async rollbackTransaction(
    driver: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['driver'],
  ): Promise<void> {
    await driver.query('ROLLBACK');
  }

  private async executeStatement(
    driver: SqlMigrationRunnerExecuteOptions<PostgresPlanTargetDetails>['driver'],
    statement: SqlStatement,
  ): Promise<void> {
    if (statement.params.length > 0) {
      await driver.query(statement.sql, statement.params);
      return;
    }
    await driver.query(statement.sql);
  }
}
