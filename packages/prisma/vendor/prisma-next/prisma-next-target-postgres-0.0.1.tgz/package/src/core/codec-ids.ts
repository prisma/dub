export {
  SQL_CHAR_CODEC_ID,
  SQL_FLOAT_CODEC_ID,
  SQL_INT_CODEC_ID,
  SQL_TEXT_CODEC_ID,
  SQL_TIMESTAMP_CODEC_ID,
  SQL_VARCHAR_CODEC_ID,
} from '@prisma-next/sql-relational-core/ast';
export const PG_TEXT_CODEC_ID = 'pg/text@1' as const;
export const PG_ENUM_CODEC_ID = 'pg/enum@1' as const;
export const PG_CHAR_CODEC_ID = 'pg/char@1' as const;
export const PG_VARCHAR_CODEC_ID = 'pg/varchar@1' as const;
export const PG_INT_CODEC_ID = 'pg/int@1' as const;
export const PG_INT2_CODEC_ID = 'pg/int2@1' as const;
export const PG_INT4_CODEC_ID = 'pg/int4@1' as const;
export const PG_INT8_CODEC_ID = 'pg/int8@1' as const;
export const PG_FLOAT_CODEC_ID = 'pg/float@1' as const;
export const PG_FLOAT4_CODEC_ID = 'pg/float4@1' as const;
export const PG_FLOAT8_CODEC_ID = 'pg/float8@1' as const;
export const PG_NUMERIC_CODEC_ID = 'pg/numeric@1' as const;
export const PG_BOOL_CODEC_ID = 'pg/bool@1' as const;
export const PG_BIT_CODEC_ID = 'pg/bit@1' as const;
export const PG_VARBIT_CODEC_ID = 'pg/varbit@1' as const;
export const PG_TIMESTAMP_CODEC_ID = 'pg/timestamp@1' as const;
export const PG_TIMESTAMPTZ_CODEC_ID = 'pg/timestamptz@1' as const;
export const PG_TIME_CODEC_ID = 'pg/time@1' as const;
export const PG_TIMETZ_CODEC_ID = 'pg/timetz@1' as const;
export const PG_INTERVAL_CODEC_ID = 'pg/interval@1' as const;
export const PG_JSON_CODEC_ID = 'pg/json@1' as const;
export const PG_JSONB_CODEC_ID = 'pg/jsonb@1' as const;
