import type { Contract } from '@prisma-next/contract/types';
import type {
  MigrationOperationPolicy,
  SqlMigrationPlannerPlanOptions,
  SqlPlannerFailureResult,
} from '@prisma-next/family-sql/control';
import {
  extractCodecControlHooks,
  planFieldEventOperations,
  plannerFailure,
} from '@prisma-next/family-sql/control';
import { verifySqlSchema } from '@prisma-next/family-sql/schema-verify';
import type { TargetBoundComponentDescriptor } from '@prisma-next/framework-components/components';
import type {
  MigrationPlanner,
  MigrationPlanWithAuthoringSurface,
  MigrationScaffoldContext,
  SchemaIssue,
} from '@prisma-next/framework-components/control';
import { parsePostgresDefault } from '../default-normalizer';
import { normalizeSchemaNativeType } from '../native-type-normalizer';
import { planIssues } from './issue-planner';
import { TypeScriptRenderablePostgresMigration } from './planner-produced-postgres-migration';
import { postgresPlannerStrategies } from './planner-strategies';

type PlannerFrameworkComponents = SqlMigrationPlannerPlanOptions extends {
  readonly frameworkComponents: infer T;
}
  ? T
  : ReadonlyArray<unknown>;

type PlannerOptionsWithComponents = SqlMigrationPlannerPlanOptions & {
  readonly frameworkComponents: PlannerFrameworkComponents;
};

type VerifySqlSchemaOptionsWithComponents = Parameters<typeof verifySqlSchema>[0] & {
  readonly frameworkComponents: PlannerFrameworkComponents;
};

interface PlannerConfig {
  readonly defaultSchema: string;
}

const DEFAULT_PLANNER_CONFIG: PlannerConfig = {
  defaultSchema: 'public',
};

export function createPostgresMigrationPlanner(
  config: Partial<PlannerConfig> = {},
): PostgresMigrationPlanner {
  return new PostgresMigrationPlanner({
    ...DEFAULT_PLANNER_CONFIG,
    ...config,
  });
}

/**
 * Result of `PostgresMigrationPlanner.plan()`. A discriminated union whose
 * success variant carries a `TypeScriptRenderablePostgresMigration` — a
 * migration object that both the CLI (via `renderTypeScript()`) and the
 * SQL-typed callers (via `operations`, `describe()`, etc.) consume
 * uniformly.
 */
export type PostgresPlanResult =
  | { readonly kind: 'success'; readonly plan: TypeScriptRenderablePostgresMigration }
  | SqlPlannerFailureResult;

/**
 * Postgres migration planner — a thin wrapper over `planIssues`.
 *
 * `plan()` verifies the live schema against the target contract (producing
 * `SchemaIssue[]`) and delegates to `planIssues` with the unified
 * `postgresPlannerStrategies` list: enum-change, NOT-NULL backfill,
 * type-change, nullable-tightening, codec-hook storage types,
 * component-declared dependency installs, and shared-temp-default /
 * empty-table-guarded NOT-NULL add-column. The same strategy list runs for
 * `migration plan`, `db update`, and `db init`; behavior diverges purely on
 * `policy.allowedOperationClasses` (the data-safe strategies short-circuit
 * when `'data'` is excluded). The issue planner applies operation-class
 * policy gates and emits a single `PostgresOpFactoryCall[]` that drives both
 * the runtime-ops view (via `renderOps`) and the `renderTypeScript()`
 * authoring surface.
 */
export class PostgresMigrationPlanner implements MigrationPlanner<'sql', 'postgres'> {
  constructor(private readonly config: PlannerConfig) {}

  plan(options: {
    readonly contract: unknown;
    readonly schema: unknown;
    readonly policy: MigrationOperationPolicy;
    /**
     * The "from" contract (state the planner assumes the database starts
     * at), or `null` for reconciliation flows. Only `migration plan` ever
     * supplies a non-null value; `db update` / `db init` reconcile against
     * the live schema and pass `null`. When present alongside the
     * `'data'` operation class, strategies that need from/to column-shape
     * comparisons (unsafe type change, nullability tightening) activate.
     *
     * Typed as the framework `Contract | null` to satisfy the
     * `MigrationPlanner` interface contract; `planSql` narrows to the SQL
     * shape via `SqlMigrationPlannerPlanOptions`. Used to populate
     * `describe().from` on the produced plan as
     * `fromContract?.storage.storageHash ?? null`.
     */
    readonly fromContract: Contract | null;
    readonly schemaName?: string;
    readonly frameworkComponents: ReadonlyArray<TargetBoundComponentDescriptor<'sql', string>>;
    /**
     * Contract space this plan applies to. Stamped onto the produced
     * {@link TypeScriptRenderablePostgresMigration.spaceId} so the runner keys
     * the marker row by the right space.
     */
    readonly spaceId: string;
  }): PostgresPlanResult {
    return this.planSql(options as SqlMigrationPlannerPlanOptions);
  }

  emptyMigration(
    context: MigrationScaffoldContext,
    spaceId: string,
  ): MigrationPlanWithAuthoringSurface {
    return new TypeScriptRenderablePostgresMigration(
      [],
      {
        from: context.fromHash,
        to: context.toHash,
      },
      spaceId,
    );
  }

  private planSql(options: SqlMigrationPlannerPlanOptions): PostgresPlanResult {
    const schemaName = options.schemaName ?? this.config.defaultSchema;
    const policyResult = this.ensureAdditivePolicy(options.policy);
    if (policyResult) {
      return policyResult;
    }

    const schemaIssues = this.collectSchemaIssues(options);
    const codecHooks = extractCodecControlHooks(options.frameworkComponents);
    const storageTypes = options.contract.storage.types ?? {};

    const result = planIssues({
      issues: schemaIssues,
      toContract: options.contract,
      // `fromContract` is only supplied by `migration plan`. It is `null` for
      // `db update` / `db init`, which means data-safety strategies needing
      // from/to comparisons (unsafe type change, nullable tightening) are
      // inapplicable there — reconciliation falls through to
      // `mapIssueToCall`'s direct destructive handlers.
      fromContract: options.fromContract,
      schemaName,
      codecHooks,
      storageTypes,
      schema: options.schema,
      policy: options.policy,
      frameworkComponents: options.frameworkComponents,
      strategies: postgresPlannerStrategies,
    });

    if (!result.ok) {
      return plannerFailure(result.failure);
    }

    // Inline `onFieldEvent`-emitted ops after structural DDL. The fixed
    // ordering is `structural → added → dropped → altered`, with
    // within-group sorting by `(tableName, fieldName)` so re-emits are
    // byte-stable. The hook fires only at the application emitter —
    // extension-space planning never reaches this helper.
    const fieldEventOps = planFieldEventOperations({
      priorContract: options.fromContract,
      newContract: options.contract,
      codecHooks,
    });
    // Codec-emitted calls already conform to `OpFactoryCall` — render +
    // toOp + importRequirements ride directly through the same emit path
    // as structural ops, no `RawSqlCall` wrap.
    const calls = [...result.value.calls, ...fieldEventOps];

    return Object.freeze({
      kind: 'success' as const,
      plan: new TypeScriptRenderablePostgresMigration(
        calls,
        {
          from: options.fromContract?.storage.storageHash ?? null,
          to: options.contract.storage.storageHash,
        },
        options.spaceId,
      ),
    });
  }

  private ensureAdditivePolicy(policy: MigrationOperationPolicy) {
    if (!policy.allowedOperationClasses.includes('additive')) {
      return plannerFailure([
        {
          kind: 'unsupportedOperation',
          summary: 'Migration planner requires additive operations be allowed',
          why: 'The planner requires the "additive" operation class to be allowed in the policy.',
        },
      ]);
    }
    return null;
  }

  private collectSchemaIssues(options: PlannerOptionsWithComponents): readonly SchemaIssue[] {
    // `db init` uses additive-only policy and intentionally ignores extra
    // schema objects. Any reconciliation-capable policy (widening or
    // destructive) must inspect extras to reconcile strict equality.
    const allowed = options.policy.allowedOperationClasses;
    const strict = allowed.includes('widening') || allowed.includes('destructive');
    const verifyOptions: VerifySqlSchemaOptionsWithComponents = {
      contract: options.contract,
      schema: options.schema,
      strict,
      typeMetadataRegistry: new Map(),
      frameworkComponents: options.frameworkComponents,
      normalizeDefault: parsePostgresDefault,
      normalizeNativeType: normalizeSchemaNativeType,
    };
    const verifyResult = verifySqlSchema(verifyOptions);
    return verifyResult.schema.issues;
  }
}
