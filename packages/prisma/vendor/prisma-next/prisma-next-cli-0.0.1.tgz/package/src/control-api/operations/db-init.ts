import type { Contract } from '@prisma-next/contract/types';
import type { TargetBoundComponentDescriptor } from '@prisma-next/framework-components/components';
import type {
  ControlDriverInstance,
  ControlExtensionDescriptor,
  ControlFamilyInstance,
  TargetMigrationsCapability,
} from '@prisma-next/framework-components/control';
import { ifDefined } from '@prisma-next/utils/defined';
import type { DbInitResult, OnControlProgress } from '../types';
import { executeAggregateApply } from './db-apply-aggregate';

/**
 * Options for executing the `db init` operation.
 *
 * `db init` runs the loader → planner → runner pipeline:
 *
 * 1. {@link executeAggregateApply} loads a `ContractSpaceAggregate` via
 *    {@link import('@prisma-next/migration-tools/aggregate').loadContractSpaceAggregate}
 *    from the supplied descriptor set + on-disk on-disk artefacts.
 * 2. The aggregate planner runs with `callerPolicy.ignoreGraphFor`
 *    locked to the app member — synth strategy for the app, graph-walk
 *    for every extension.
 * 3. The runner's `executeAcrossSpaces` applies the per-space plans
 *    inside one outer transaction.
 *
 * `extensionPacks` mirrors `Config.extensionPacks` (descriptor list).
 * The loader (sub-spec § Loader) is the sole descriptor-import boundary.
 */
export interface ExecuteDbInitOptions<TFamilyId extends string, TTargetId extends string> {
  readonly driver: ControlDriverInstance<TFamilyId, TTargetId>;
  readonly familyInstance: ControlFamilyInstance<TFamilyId, unknown>;
  readonly contract: Contract;
  readonly mode: 'plan' | 'apply';
  readonly migrations: TargetMigrationsCapability<
    TFamilyId,
    TTargetId,
    ControlFamilyInstance<TFamilyId, unknown>
  >;
  readonly frameworkComponents: ReadonlyArray<TargetBoundComponentDescriptor<TFamilyId, TTargetId>>;
  /**
   * On-disk migrations directory the aggregate loader reads on-disk
   * artefacts from. Required.
   */
  readonly migrationsDir: string;
  /**
   * Resolved adapter target id. Threaded through to the loader for
   * target-consistency checks across descriptors and the app contract.
   */
  readonly targetId: TTargetId;
  /**
   * Declared extension descriptors. Defaults to an empty list, which
   * routes through the same loader → planner → runner pipeline with no
   * extension members in the aggregate.
   */
  readonly extensionPacks?: ReadonlyArray<ControlExtensionDescriptor<TFamilyId, TTargetId>>;
  /** Optional progress callback for observing operation progress */
  readonly onProgress?: OnControlProgress;
}

/**
 * Execute `db init` against the configured contract.
 *
 * Routes through the loader → planner → runner pipeline (sub-spec
 * "Commit-by-commit § Commit 4"). Always additive-only; destructive
 * changes belong to `db update`.
 */
export async function executeDbInit<TFamilyId extends string, TTargetId extends string>(
  options: ExecuteDbInitOptions<TFamilyId, TTargetId>,
): Promise<DbInitResult> {
  const result = await executeAggregateApply<TFamilyId, TTargetId>({
    driver: options.driver,
    familyInstance: options.familyInstance,
    contract: options.contract,
    mode: options.mode,
    migrations: options.migrations,
    frameworkComponents: options.frameworkComponents,
    migrationsDir: options.migrationsDir,
    targetId: options.targetId,
    extensionPacks: options.extensionPacks ?? [],
    policy: { allowedOperationClasses: ['additive'] },
    action: 'dbInit',
    ...ifDefined('onProgress', options.onProgress),
  });
  return result as DbInitResult;
}
