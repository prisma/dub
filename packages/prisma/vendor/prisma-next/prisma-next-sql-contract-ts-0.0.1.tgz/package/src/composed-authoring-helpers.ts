import type {
  AuthoringArgumentDescriptor,
  AuthoringFieldNamespace,
  AuthoringTypeConstructorDescriptor,
  AuthoringTypeNamespace,
} from '@prisma-next/framework-components/authoring';
import {
  assertNoCrossRegistryCollisions,
  isAuthoringFieldPresetDescriptor,
  isAuthoringTypeConstructorDescriptor,
  mergeAuthoringNamespaces,
} from '@prisma-next/framework-components/authoring';
import type {
  ExtensionPackRef,
  FamilyPackRef,
  TargetPackRef,
} from '@prisma-next/framework-components/components';
import {
  createFieldHelpersFromNamespace,
  createFieldPresetHelper,
  createTypeHelpersFromNamespace,
} from './authoring-helper-runtime';
import type {
  FieldHelpersFromNamespace,
  ResolveTemplateValue,
  TupleFromArgumentDescriptors,
  UnionToIntersection,
} from './authoring-type-utils';
import type {
  AnyRelationBuilder,
  ContractModelBuilder,
  IndexTypeMap,
  ScalarFieldBuilder,
} from './contract-dsl';
import { buildFieldPreset, field, model, rel } from './contract-dsl';
import type { MergeExtensionIndexTypes } from './contract-types';

type ExtractTypeNamespaceFromPack<Pack> = Pack extends {
  readonly authoring?: { readonly type?: infer Namespace extends AuthoringTypeNamespace };
}
  ? Namespace
  : Record<never, never>;

type ExtractFieldNamespaceFromPack<Pack> = Pack extends {
  readonly authoring?: { readonly field?: infer Namespace extends AuthoringFieldNamespace };
}
  ? Namespace
  : Record<never, never>;

type MergeExtensionTypeNamespaces<ExtensionPacks> =
  ExtensionPacks extends Record<string, unknown>
    ? keyof ExtensionPacks extends never
      ? Record<never, never>
      : UnionToIntersection<
          {
            [K in keyof ExtensionPacks]: ExtractTypeNamespaceFromPack<ExtensionPacks[K]>;
          }[keyof ExtensionPacks]
        >
    : Record<never, never>;

type MergeExtensionFieldNamespaces<ExtensionPacks> =
  ExtensionPacks extends Record<string, unknown>
    ? keyof ExtensionPacks extends never
      ? Record<never, never>
      : UnionToIntersection<
          {
            [K in keyof ExtensionPacks]: ExtractFieldNamespaceFromPack<ExtensionPacks[K]>;
          }[keyof ExtensionPacks]
        >
    : Record<never, never>;

type StorageTypeFromDescriptor<
  Descriptor extends AuthoringTypeConstructorDescriptor,
  Args extends readonly unknown[],
> = {
  readonly codecId: ResolveTemplateValue<Descriptor['output']['codecId'], Args>;
  readonly nativeType: ResolveTemplateValue<Descriptor['output']['nativeType'], Args>;
} & (Descriptor['output'] extends {
  readonly typeParams: infer TypeParams extends Record<string, unknown>;
}
  ? {
      readonly typeParams: ResolveTemplateValue<TypeParams, Args>;
    }
  : Record<never, never>);

type TypeHelperFunction<Descriptor extends AuthoringTypeConstructorDescriptor> =
  Descriptor extends { readonly args: infer Args extends readonly AuthoringArgumentDescriptor[] }
    ? <const Params extends TupleFromArgumentDescriptors<Args>>(
        ...args: Params
      ) => StorageTypeFromDescriptor<Descriptor, Params>
    : () => StorageTypeFromDescriptor<Descriptor, readonly []>;

type TypeHelpersFromNamespace<Namespace> = {
  readonly [K in keyof Namespace]: Namespace[K] extends AuthoringTypeConstructorDescriptor
    ? TypeHelperFunction<Namespace[K]>
    : Namespace[K] extends Record<string, unknown>
      ? TypeHelpersFromNamespace<Namespace[K]>
      : never;
};

type CoreFieldHelpers = Pick<typeof field, 'column' | 'generated' | 'namedType'>;

type MergeAllPackIndexTypes<Family, Target, ExtensionPacks> = MergeExtensionIndexTypes<
  { readonly __family: Family; readonly __target: Target } & (ExtensionPacks extends Record<
    string,
    unknown
  >
    ? ExtensionPacks
    : Record<never, never>)
>;

type PackAwareModel<IndexTypes extends IndexTypeMap> = {
  <
    const ModelName extends string,
    Fields extends Record<string, ScalarFieldBuilder>,
    Relations extends Record<string, AnyRelationBuilder> = Record<never, never>,
  >(
    modelName: ModelName,
    input: { readonly fields: Fields; readonly relations?: Relations },
  ): ContractModelBuilder<ModelName, Fields, Relations, undefined, undefined, IndexTypes>;
  <
    Fields extends Record<string, ScalarFieldBuilder>,
    Relations extends Record<string, AnyRelationBuilder> = Record<never, never>,
  >(input: {
    readonly fields: Fields;
    readonly relations?: Relations;
  }): ContractModelBuilder<undefined, Fields, Relations, undefined, undefined, IndexTypes>;
};

export type ComposedAuthoringHelpers<
  Family extends FamilyPackRef<string>,
  Target extends TargetPackRef<'sql', string>,
  ExtensionPacks extends Record<string, ExtensionPackRef<'sql', string>> | undefined,
> = {
  readonly field: CoreFieldHelpers &
    FieldHelpersFromNamespace<
      ExtractFieldNamespaceFromPack<Family> &
        ExtractFieldNamespaceFromPack<Target> &
        MergeExtensionFieldNamespaces<ExtensionPacks>
    >;
  readonly model: PackAwareModel<MergeAllPackIndexTypes<Family, Target, ExtensionPacks>>;
  readonly rel: typeof rel;
  readonly type: TypeHelpersFromNamespace<
    ExtractTypeNamespaceFromPack<Family> &
      ExtractTypeNamespaceFromPack<Target> &
      MergeExtensionTypeNamespaces<ExtensionPacks>
  >;
};

function extractTypeNamespace<Pack>(pack: Pack): ExtractTypeNamespaceFromPack<Pack> {
  return ((pack as { readonly authoring?: { readonly type?: unknown } }).authoring?.type ??
    {}) as ExtractTypeNamespaceFromPack<Pack>;
}

function extractFieldNamespace<Pack>(pack: Pack): ExtractFieldNamespaceFromPack<Pack> {
  return ((pack as { readonly authoring?: { readonly field?: unknown } }).authoring?.field ??
    {}) as ExtractFieldNamespaceFromPack<Pack>;
}

type AuthoringComponent = {
  readonly authoring?: { readonly type?: unknown; readonly field?: unknown };
};

function composeTypeNamespace(components: readonly AuthoringComponent[]): AuthoringTypeNamespace {
  const merged: Record<string, unknown> = {};
  for (const component of components) {
    const ns = extractTypeNamespace(component);
    if (Object.keys(ns).length > 0) {
      mergeAuthoringNamespaces(merged, ns, [], isAuthoringTypeConstructorDescriptor, 'type');
    }
  }
  return merged as AuthoringTypeNamespace;
}

function composeFieldNamespace(components: readonly AuthoringComponent[]): AuthoringFieldNamespace {
  const merged: Record<string, unknown> = {};
  for (const component of components) {
    const ns = extractFieldNamespace(component);
    if (Object.keys(ns).length > 0) {
      mergeAuthoringNamespaces(merged, ns, [], isAuthoringFieldPresetDescriptor, 'field');
    }
  }
  return merged as AuthoringFieldNamespace;
}

function createComposedFieldHelpers(
  fieldNamespace: AuthoringFieldNamespace,
): CoreFieldHelpers & Record<string, unknown> {
  const helperNamespace = createFieldHelpersFromNamespace(
    fieldNamespace,
    ({ helperPath, descriptor }) =>
      createFieldPresetHelper({
        helperPath,
        descriptor,
        build: ({ args, namedConstraintOptions }) =>
          buildFieldPreset(descriptor, args, namedConstraintOptions),
      }),
  );
  const coreFieldHelpers = {
    column: field.column,
    generated: field.generated,
    namedType: field.namedType,
  } satisfies CoreFieldHelpers;

  const coreHelperNames = new Set(Object.keys(coreFieldHelpers));
  for (const helperName of Object.keys(helperNamespace)) {
    if (coreHelperNames.has(helperName)) {
      throw new Error(
        `Duplicate authoring field helper "${helperName}". Core field helpers reserve that name.`,
      );
    }
  }

  return {
    ...coreFieldHelpers,
    ...helperNamespace,
  };
}

export function createComposedAuthoringHelpers<
  Family extends FamilyPackRef<string>,
  Target extends TargetPackRef<'sql', string>,
  ExtensionPacks extends Record<string, ExtensionPackRef<'sql', string>> | undefined,
>(options: {
  readonly family: Family;
  readonly target: Target;
  readonly extensionPacks?: ExtensionPacks;
}): ComposedAuthoringHelpers<Family, Target, ExtensionPacks> {
  const extensionValues: readonly ExtensionPackRef<'sql', string>[] = Object.values(
    (options.extensionPacks ?? {}) as Record<string, ExtensionPackRef<'sql', string>>,
  );
  const components: readonly AuthoringComponent[] = [
    options.family,
    options.target,
    ...extensionValues,
  ];

  const typeNamespace = composeTypeNamespace(components);
  const fieldNamespace = composeFieldNamespace(components);
  // Mirrors the call in `assembleAuthoringContributions`: PSL composes via
  // `createControlStack`, the TS DSL composes here. Both seams need the guard.
  assertNoCrossRegistryCollisions(typeNamespace, fieldNamespace);

  return {
    field: createComposedFieldHelpers(fieldNamespace),
    model,
    rel,
    type: createTypeHelpersFromNamespace(typeNamespace),
  } as ComposedAuthoringHelpers<Family, Target, ExtensionPacks>;
}
