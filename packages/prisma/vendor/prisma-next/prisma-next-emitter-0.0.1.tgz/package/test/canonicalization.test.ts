import { canonicalizeContract } from '@prisma-next/contract/hashing';
import { describe, expect, it } from 'vitest';
import { createTestContract } from './utils';

describe('canonicalization', () => {
  it('orders top-level sections correctly', () => {
    const ir = createTestContract({
      capabilities: { postgres: { jsonAgg: true } },
      meta: { emitterVersion: 'test' },
    });

    const result = canonicalizeContract(ir);
    const parsed = JSON.parse(result) as Record<string, unknown>;

    const keys = Object.keys(parsed);
    const schemaVersionIndex = keys.indexOf('schemaVersion');
    const targetFamilyIndex = keys.indexOf('targetFamily');
    const targetIndex = keys.indexOf('target');
    const modelsIndex = keys.indexOf('models');
    const storageIndex = keys.indexOf('storage');
    const capabilitiesIndex = keys.indexOf('capabilities');
    const metaIndex = keys.indexOf('meta');

    expect(schemaVersionIndex).toBeLessThan(targetFamilyIndex);
    expect(targetFamilyIndex).toBeLessThan(targetIndex);
    expect(targetIndex).toBeLessThan(modelsIndex);
    expect(modelsIndex).toBeLessThan(storageIndex);
    expect(storageIndex).toBeLessThan(capabilitiesIndex);
    expect(capabilitiesIndex).toBeLessThan(metaIndex);
  });

  it('preserves nullable false on columns', () => {
    const ir = createTestContract({
      storage: {
        tables: {
          user: {
            columns: {
              id: { codecId: 'pg/int4@1', nativeType: 'int4', nullable: false },
              email: { codecId: 'pg/text@1', nativeType: 'text', nullable: true },
            },
          },
        },
      },
    });

    const result = canonicalizeContract(ir);
    const parsed = JSON.parse(result) as Record<string, unknown>;
    const storage = parsed['storage'] as Record<string, unknown>;
    const tables = storage['tables'] as Record<string, unknown>;
    const user = tables['user'] as Record<string, unknown>;
    const columns = user['columns'] as Record<string, unknown>;
    const id = columns['id'] as Record<string, unknown>;
    const email = columns['email'] as Record<string, unknown>;
    expect(id['nullable']).toBe(false);
    expect(email['nullable']).toBe(true);
  });

  it('preserves nullable:false for columns with defaults', () => {
    const ir = createTestContract({
      storage: {
        tables: {
          user: {
            columns: {
              created_at: {
                codecId: 'pg/timestamptz@1',
                nativeType: 'timestamptz',
                nullable: false,
                default: { kind: 'function', expression: 'now()' },
              },
              updated_at: {
                codecId: 'pg/timestamptz@1',
                nativeType: 'timestamptz',
                nullable: true,
              },
            },
          },
        },
      },
    });

    const result = canonicalizeContract(ir);
    const parsed = JSON.parse(result) as Record<string, unknown>;
    const storage = parsed['storage'] as Record<string, unknown>;
    const tables = storage['tables'] as Record<string, unknown>;
    const user = tables['user'] as Record<string, unknown>;
    const columns = user['columns'] as Record<string, unknown>;
    const createdAt = columns['created_at'] as Record<string, unknown>;
    const updatedAt = columns['updated_at'] as Record<string, unknown>;
    expect(createdAt['nullable']).toBe(false);
    expect(updatedAt['nullable']).toBe(true);
  });

  it('preserves nullable:true for columns with defaults', () => {
    const ir = createTestContract({
      storage: {
        tables: {
          user: {
            columns: {
              bio: {
                codecId: 'pg/text@1',
                nativeType: 'text',
                nullable: true,
                default: { kind: 'literal', value: '' },
              },
            },
          },
        },
      },
    });

    const result = canonicalizeContract(ir);
    const parsed = JSON.parse(result) as Record<string, unknown>;
    const storage = parsed['storage'] as Record<string, unknown>;
    const tables = storage['tables'] as Record<string, unknown>;
    const user = tables['user'] as Record<string, unknown>;
    const columns = user['columns'] as Record<string, unknown>;
    const bio = columns['bio'] as Record<string, unknown>;
    expect(bio['nullable']).toBe(true);
    expect(bio['default']).toEqual({ kind: 'literal', value: '' });
  });

  it('omits empty arrays and objects except required ones', () => {
    const ir = createTestContract();

    const result = canonicalizeContract(ir);
    const parsed = JSON.parse(result);
    expect(parsed).toMatchObject({
      models: expect.anything(),
      storage: {
        tables: expect.anything(),
      },
    });
    // Required top-level fields (capabilities, extensionPacks, meta) are preserved even when empty.
    expect(parsed).toMatchObject({
      capabilities: expect.anything(),
      extensionPacks: expect.anything(),
      meta: expect.anything(),
    });
    expect(parsed).not.toHaveProperty('relations');
  });

  it('preserves semantic array order for column lists', () => {
    const ir = createTestContract({
      storage: {
        tables: {
          user: {
            columns: {
              first: { codecId: 'pg/text@1', nativeType: 'text', nullable: false },
              second: { codecId: 'pg/text@1', nativeType: 'text', nullable: false },
            },
            primaryKey: {
              columns: ['second', 'first'],
            },
          },
        },
      },
    });

    const result1 = canonicalizeContract(ir);

    const ir2 = createTestContract({
      storage: {
        tables: {
          user: {
            columns: {
              first: { codecId: 'pg/text@1', nativeType: 'text', nullable: false },
              second: { codecId: 'pg/text@1', nativeType: 'text', nullable: false },
            },
            primaryKey: {
              columns: ['first', 'second'],
            },
          },
        },
      },
    });

    const result2 = canonicalizeContract(ir2);

    expect(result1).not.toBe(result2);
  });

  it('sorts indexes by canonical name', () => {
    const ir = createTestContract({
      storage: {
        tables: {
          user: {
            columns: {
              id: { codecId: 'pg/int4@1', nativeType: 'int4', nullable: false },
            },
            indexes: [
              { columns: ['id'], name: 'user_email_idx' },
              { columns: ['id'], name: 'user_name_idx' },
            ],
          },
        },
      },
    });

    const result = canonicalizeContract(ir);
    const parsed = JSON.parse(result) as Record<string, unknown>;
    const storage = parsed['storage'] as Record<string, unknown>;
    const tables = storage['tables'] as Record<string, unknown>;
    const user = tables['user'] as Record<string, unknown>;
    const indexes = user['indexes'] as Array<{ name: string }>;
    const indexNames = indexes.map((idx) => idx.name);
    expect(indexNames).toEqual(['user_email_idx', 'user_name_idx']);
  });

  it('sorts uniques by canonical name', () => {
    const ir = createTestContract({
      storage: {
        tables: {
          user: {
            columns: {
              id: { codecId: 'pg/int4@1', nativeType: 'int4', nullable: false },
              email: { codecId: 'pg/text@1', nativeType: 'text', nullable: false },
              username: { codecId: 'pg/text@1', nativeType: 'text', nullable: false },
            },
            uniques: [
              { columns: ['username'], name: 'user_username_key' },
              { columns: ['email'], name: 'user_email_key' },
            ],
          },
        },
      },
    });

    const result = canonicalizeContract(ir);
    const parsed = JSON.parse(result) as Record<string, unknown>;
    const storage = parsed['storage'] as Record<string, unknown>;
    const tables = storage['tables'] as Record<string, unknown>;
    const user = tables['user'] as Record<string, unknown>;
    const uniques = user['uniques'] as Array<{ name: string }>;
    const uniqueNames = uniques.map((u) => u.name);
    expect(uniqueNames).toEqual(['user_email_key', 'user_username_key']);
  });

  it('preserves column order in composite unique constraints', () => {
    const ir = createTestContract({
      storage: {
        tables: {
          user: {
            columns: {
              id: { codecId: 'pg/int4@1', nativeType: 'int4', nullable: false },
              first_name: { codecId: 'pg/text@1', nativeType: 'text', nullable: false },
              last_name: { codecId: 'pg/text@1', nativeType: 'text', nullable: false },
            },
            uniques: [{ columns: ['last_name', 'first_name'], name: 'user_name_key' }],
          },
        },
      },
    });

    const result = canonicalizeContract(ir);
    const parsed = JSON.parse(result) as Record<string, unknown>;
    const storage = parsed['storage'] as Record<string, unknown>;
    const tables = storage['tables'] as Record<string, unknown>;
    const user = tables['user'] as Record<string, unknown>;
    const uniques = user['uniques'] as Array<{ columns: string[] }>;
    expect(uniques[0]!.columns).toEqual(['last_name', 'first_name']);
  });

  it('sorts nested object keys lexicographically', () => {
    const ir = createTestContract({
      storage: {
        tables: {
          user: {
            columns: {
              z_field: { codecId: 'pg/text@1', nativeType: 'text', nullable: false },
              a_field: { codecId: 'pg/text@1', nativeType: 'text', nullable: false },
              m_field: { codecId: 'pg/text@1', nativeType: 'text', nullable: false },
            },
          },
        },
      },
    });

    const result = canonicalizeContract(ir);
    const parsed = JSON.parse(result) as Record<string, unknown>;
    const storage = parsed['storage'] as Record<string, unknown>;
    const tables = storage['tables'] as Record<string, unknown>;
    const user = tables['user'] as Record<string, unknown>;
    const columns = user['columns'] as Record<string, unknown>;
    const columnKeys = Object.keys(columns);
    expect(columnKeys).toEqual(['a_field', 'm_field', 'z_field']);
  });

  describe('Mongo storage.collections preservation', () => {
    it('preserves empty storage.collections container', () => {
      const ir = createTestContract({
        targetFamily: 'mongo',
        target: 'mongo',
        storage: { collections: {} },
      });

      const result = canonicalizeContract(ir);
      const parsed = JSON.parse(result) as Record<string, unknown>;
      const storage = parsed['storage'] as Record<string, unknown>;
      expect(storage['collections']).toEqual({});
    });

    it('preserves collection entries with empty payloads', () => {
      const ir = createTestContract({
        targetFamily: 'mongo',
        target: 'mongo',
        storage: { collections: { users: {}, posts: {} } },
      });

      const result = canonicalizeContract(ir);
      const parsed = JSON.parse(result) as Record<string, unknown>;
      const storage = parsed['storage'] as Record<string, unknown>;
      const collections = storage['collections'] as Record<string, unknown>;
      expect(collections['users']).toEqual({});
      expect(collections['posts']).toEqual({});
    });

    it('sorts collection names lexicographically', () => {
      const ir = createTestContract({
        targetFamily: 'mongo',
        target: 'mongo',
        storage: { collections: { zebras: {}, apples: {}, mangoes: {} } },
      });

      const result = canonicalizeContract(ir);
      const parsed = JSON.parse(result) as Record<string, unknown>;
      const storage = parsed['storage'] as Record<string, unknown>;
      const collections = storage['collections'] as Record<string, unknown>;
      expect(Object.keys(collections)).toEqual(['apples', 'mangoes', 'zebras']);
    });

    it('produces different hashes when collections differ', () => {
      const ir1 = createTestContract({
        targetFamily: 'mongo',
        target: 'mongo',
        storage: { collections: { users: {} } },
      });
      const ir2 = createTestContract({
        targetFamily: 'mongo',
        target: 'mongo',
        storage: { collections: { users: {}, posts: {} } },
      });

      const result1 = canonicalizeContract(ir1);
      const result2 = canonicalizeContract(ir2);
      expect(result1).not.toBe(result2);
    });
  });

  it('sorts extension namespaces lexicographically', () => {
    const ir = createTestContract({
      extensionPacks: {
        pgvector: { version: '0.0.1' },
        postgres: { version: '0.0.1' },
        another: { version: '0.0.1' },
      },
    });

    const result = canonicalizeContract(ir);
    const parsed = JSON.parse(result) as Record<string, unknown>;
    const extensionPacks = parsed['extensionPacks'] as Record<string, unknown>;
    const extensionKeys = Object.keys(extensionPacks);
    expect(extensionKeys).toEqual(['another', 'pgvector', 'postgres']);
  });

  it('omits generated false', () => {
    const ir = createTestContract({
      storage: {
        tables: {
          user: {
            columns: {
              id: { codecId: 'pg/int4@1', nativeType: 'int4', nullable: false, generated: false },
            },
          },
        },
      },
    });

    const result = canonicalizeContract(ir);
    const parsed = JSON.parse(result) as Record<string, unknown>;
    const storage = parsed['storage'] as Record<string, unknown>;
    const tables = storage['tables'] as Record<string, unknown>;
    const user = tables['user'] as Record<string, unknown>;
    const columns = user['columns'] as Record<string, unknown>;
    const id = columns['id'] as Record<string, unknown>;
    expect(id['generated']).toBeUndefined();
  });
});
