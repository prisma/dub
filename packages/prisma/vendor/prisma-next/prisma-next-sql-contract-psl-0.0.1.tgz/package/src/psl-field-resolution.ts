import type { ContractSourceDiagnostic } from '@prisma-next/config/config-types';
import type { ColumnDefault, ExecutionMutationDefaultPhases } from '@prisma-next/contract/types';
import type { AuthoringContributions } from '@prisma-next/framework-components/authoring';
import type {
  ControlMutationDefaultRegistry,
  MutationDefaultGeneratorDescriptor,
} from '@prisma-next/framework-components/control';
import type { PslAttribute, PslField, PslModel } from '@prisma-next/psl-parser';
import { ifDefined } from '@prisma-next/utils/defined';
import {
  getAttribute,
  lowerFirst,
  parseConstraintMapArgument,
  parseMapName,
} from './psl-attribute-parsing';
import type { ColumnDescriptor, FieldPresetContributions } from './psl-column-resolution';
import {
  checkUncomposedNamespace,
  lowerDefaultForField,
  reportUncomposedNamespace,
  resolveFieldTypeDescriptor,
} from './psl-column-resolution';

export type ResolvedField = {
  readonly field: PslField;
  readonly columnName: string;
  readonly descriptor: ColumnDescriptor;
  readonly defaultValue?: ColumnDefault;
  readonly executionDefaults?: ExecutionMutationDefaultPhases;
  readonly isId: boolean;
  readonly isUnique: boolean;
  readonly idName?: string;
  readonly uniqueName?: string;
  readonly many?: true;
  readonly valueObjectTypeName?: string;
  readonly scalarCodecId?: string;
};

export type ModelNameMapping = {
  readonly model: PslModel;
  readonly tableName: string;
  readonly fieldColumns: Map<string, string>;
};

export interface CollectResolvedFieldsInput {
  readonly model: PslModel;
  readonly mapping: ModelNameMapping;
  readonly enumTypeDescriptors: Map<string, ColumnDescriptor>;
  readonly namedTypeDescriptors: Map<string, ColumnDescriptor>;
  readonly modelNames: Set<string>;
  readonly compositeTypeNames: ReadonlySet<string>;
  readonly composedExtensions: Set<string>;
  readonly authoringContributions: AuthoringContributions | undefined;
  readonly familyId: string;
  readonly targetId: string;
  readonly defaultFunctionRegistry: ControlMutationDefaultRegistry;
  readonly generatorDescriptorById: ReadonlyMap<string, MutationDefaultGeneratorDescriptor>;
  readonly diagnostics: ContractSourceDiagnostic[];
  readonly sourceId: string;
  readonly scalarTypeDescriptors: ReadonlyMap<string, ColumnDescriptor>;
}

const BUILTIN_FIELD_ATTRIBUTE_NAMES: ReadonlySet<string> = new Set([
  'id',
  'unique',
  'default',
  'relation',
  'map',
]);

/**
 * Hardcoded migration hint for attributes that have been removed from PSL in
 * favor of the field-preset surface. The hint text is appended to the
 * `PSL_UNSUPPORTED_FIELD_ATTRIBUTE` message so users porting Prisma 6
 * schemas see "use this preset instead" inline. Suppressed when the field
 * already declares a `temporal.*` preset call (the user has already
 * migrated; the hint would tell them to do what they just did).
 *
 * Add an entry here when removing another attribute. Keep this small —
 * if the table grows past a handful of entries, factor out into a proper
 * registry.
 */
function getRemovedAttributeHint(attributeName: string): string | undefined {
  if (attributeName === 'updatedAt') {
    return 'Use `temporal.updatedAt()` as a field-preset call instead.';
  }
  return undefined;
}

function fieldDeclaresTemporalPreset(field: PslField): boolean {
  return field.typeConstructor?.path[0] === 'temporal';
}

function validateFieldAttributes(input: {
  readonly model: PslModel;
  readonly field: PslField;
  readonly composedExtensions: ReadonlySet<string>;
  readonly diagnostics: ContractSourceDiagnostic[];
  readonly sourceId: string;
  readonly familyId: string;
  readonly targetId: string;
}): void {
  for (const attribute of input.field.attributes) {
    if (BUILTIN_FIELD_ATTRIBUTE_NAMES.has(attribute.name)) {
      continue;
    }

    const uncomposedNamespace = checkUncomposedNamespace(attribute.name, input.composedExtensions, {
      familyId: input.familyId,
      targetId: input.targetId,
    });
    if (uncomposedNamespace) {
      reportUncomposedNamespace({
        subjectLabel: `Attribute "@${attribute.name}"`,
        namespace: uncomposedNamespace,
        sourceId: input.sourceId,
        span: attribute.span,
        diagnostics: input.diagnostics,
      });
      continue;
    }

    const baseMessage = `Field "${input.model.name}.${input.field.name}" uses unsupported attribute "@${attribute.name}"`;
    const removedHint = getRemovedAttributeHint(attribute.name);
    const message =
      removedHint && !fieldDeclaresTemporalPreset(input.field)
        ? `${baseMessage}. ${removedHint}`
        : baseMessage;

    input.diagnostics.push({
      code: 'PSL_UNSUPPORTED_FIELD_ATTRIBUTE',
      message,
      sourceId: input.sourceId,
      span: attribute.span,
    });
  }
}

function extractFieldConstraintNames(input: {
  readonly model: PslModel;
  readonly field: PslField;
  readonly sourceId: string;
  readonly diagnostics: ContractSourceDiagnostic[];
}): {
  readonly idAttribute: PslAttribute | undefined;
  readonly uniqueAttribute: PslAttribute | undefined;
  readonly idName: string | undefined;
  readonly uniqueName: string | undefined;
} {
  const idAttribute = getAttribute(input.field.attributes, 'id');
  const uniqueAttribute = getAttribute(input.field.attributes, 'unique');
  const idName = parseConstraintMapArgument({
    attribute: idAttribute,
    sourceId: input.sourceId,
    diagnostics: input.diagnostics,
    entityLabel: `Field "${input.model.name}.${input.field.name}" @id`,
    span: input.field.span,
    code: 'PSL_INVALID_ATTRIBUTE_ARGUMENT',
  });
  const uniqueName = parseConstraintMapArgument({
    attribute: uniqueAttribute,
    sourceId: input.sourceId,
    diagnostics: input.diagnostics,
    entityLabel: `Field "${input.model.name}.${input.field.name}" @unique`,
    span: input.field.span,
    code: 'PSL_INVALID_ATTRIBUTE_ARGUMENT',
  });
  return { idAttribute, uniqueAttribute, idName, uniqueName };
}

export function collectResolvedFields(input: CollectResolvedFieldsInput): ResolvedField[] {
  const {
    model,
    mapping,
    enumTypeDescriptors,
    namedTypeDescriptors,
    modelNames,
    compositeTypeNames,
    composedExtensions,
    authoringContributions,
    familyId,
    targetId,
    defaultFunctionRegistry,
    generatorDescriptorById,
    diagnostics,
    sourceId,
    scalarTypeDescriptors,
  } = input;
  const resolvedFields: ResolvedField[] = [];

  for (const field of model.fields) {
    const isModelField = modelNames.has(field.typeName);

    if (field.list && isModelField) {
      continue;
    }

    validateFieldAttributes({
      model,
      field,
      composedExtensions,
      diagnostics,
      sourceId,
      familyId,
      targetId,
    });

    const relationAttribute = getAttribute(field.attributes, 'relation');
    if (isModelField && relationAttribute) {
      continue;
    }

    const isValueObjectField = compositeTypeNames.has(field.typeName);
    const isListField = field.list;

    let descriptor: ColumnDescriptor | undefined;
    let scalarCodecId: string | undefined;
    let presetContributions: FieldPresetContributions | undefined;
    const resolveInput = {
      field,
      enumTypeDescriptors,
      namedTypeDescriptors,
      scalarTypeDescriptors,
      authoringContributions,
      composedExtensions,
      familyId,
      targetId,
      diagnostics,
      sourceId,
      entityLabel: `Field "${model.name}.${field.name}"`,
    };

    if (isValueObjectField) {
      descriptor = scalarTypeDescriptors.get('Json');
    } else if (isListField) {
      const resolved = resolveFieldTypeDescriptor(resolveInput);
      if (!resolved.ok) {
        if (!resolved.alreadyReported) {
          diagnostics.push({
            code: 'PSL_UNSUPPORTED_FIELD_TYPE',
            message: `Field "${model.name}.${field.name}" type "${field.typeName}" is not supported in SQL PSL provider v1`,
            sourceId,
            span: field.span,
          });
        }
        continue;
      }
      // Field presets are complete declarations — they carry their own codec
      // and do not compose with `[]` list-of semantics. Reject early.
      if (resolved.presetContributions) {
        diagnostics.push({
          code: 'PSL_PRESET_NOT_LIST',
          message: `Field "${model.name}.${field.name}" uses a field-preset call as a list element type. Presets cannot be list elements; remove "[]" or use a scalar type.`,
          sourceId,
          span: field.span,
        });
        continue;
      }
      scalarCodecId = resolved.descriptor.codecId;
      descriptor = scalarTypeDescriptors.get('Json');
    } else {
      const resolved = resolveFieldTypeDescriptor(resolveInput);
      if (!resolved.ok) {
        if (!resolved.alreadyReported) {
          diagnostics.push({
            code: 'PSL_UNSUPPORTED_FIELD_TYPE',
            message: `Field "${model.name}.${field.name}" type "${field.typeName}" is not supported in SQL PSL provider v1`,
            sourceId,
            span: field.span,
          });
        }
        continue;
      }
      descriptor = resolved.descriptor;
      presetContributions = resolved.presetContributions;
    }

    if (!descriptor) {
      continue;
    }

    // Field presets are complete declarations: the preset names its own codec
    // and contributes any combination of default / executionDefaults / id /
    // unique. Optional and `@default(...)` modifiers contradict that, so they
    // are hard errors per spec FR7.
    if (presetContributions && field.optional) {
      diagnostics.push({
        code: 'PSL_PRESET_NOT_OPTIONAL',
        message: `Field "${model.name}.${field.name}" uses a field-preset call and cannot be optional. Remove "?" or use a different field type.`,
        sourceId,
        span: field.span,
      });
      continue;
    }

    const defaultAttribute = getAttribute(field.attributes, 'default');
    if (presetContributions && defaultAttribute) {
      diagnostics.push({
        code: 'PSL_PRESET_AND_DEFAULT_CONFLICT',
        message: `Field "${model.name}.${field.name}" uses a field-preset call and cannot also declare @default(...). The preset already specifies the default value.`,
        sourceId,
        span: defaultAttribute.span,
      });
      continue;
    }
    const loweredDefault = defaultAttribute
      ? lowerDefaultForField({
          modelName: model.name,
          fieldName: field.name,
          defaultAttribute,
          columnDescriptor: descriptor,
          generatorDescriptorById,
          sourceId,
          defaultFunctionRegistry,
          diagnostics,
        })
      : {};
    const loweredOnCreate = loweredDefault.executionDefaults?.onCreate;
    if (field.optional && loweredOnCreate) {
      const generatorDescription =
        loweredOnCreate.kind === 'generator' ? `"${loweredOnCreate.id}"` : 'for this field';
      diagnostics.push({
        code: 'PSL_INVALID_DEFAULT_FUNCTION_ARGUMENT',
        message: `Field "${model.name}.${field.name}" cannot be optional when using execution default ${generatorDescription}. Remove "?" or use a storage default.`,
        sourceId,
        span: defaultAttribute?.span ?? field.span,
      });
      continue;
    }
    if (loweredOnCreate) {
      const generatorDescriptor = generatorDescriptorById.get(loweredOnCreate.id);
      const generatedDescriptor = generatorDescriptor?.resolveGeneratedColumnDescriptor?.({
        generated: loweredOnCreate,
      });
      if (generatedDescriptor) {
        descriptor = generatedDescriptor;
      }
    }
    const mappedColumnName = mapping.fieldColumns.get(field.name) ?? field.name;
    const { idAttribute, uniqueAttribute, idName, uniqueName } = extractFieldConstraintNames({
      model,
      field,
      sourceId,
      diagnostics,
    });

    // Field presets contribute their own default / executionDefaults / id /
    // unique. They take precedence over attribute-derived contributions for
    // this field, since a preset *is* the field declaration. Conflicts with
    // `@default` and optional are already rejected above; explicit `@id`
    // would be redundant noise on the resolved field, so we surface it as
    // a hard error here for symmetry.
    if (presetContributions && idAttribute && !presetContributions.id) {
      diagnostics.push({
        code: 'PSL_PRESET_AND_ID_CONFLICT',
        message: `Field "${model.name}.${field.name}" uses a field-preset call and cannot also declare @id. Use a preset that contributes id semantics, or drop @id.`,
        sourceId,
        span: idAttribute.span,
      });
      continue;
    }

    // Field-preset contributions take precedence over attribute-derived
    // sources when present.
    const fieldExecutionDefaults =
      presetContributions?.executionDefaults ?? loweredDefault.executionDefaults;
    const fieldDefaultValue = presetContributions?.default ?? loweredDefault.defaultValue;
    resolvedFields.push({
      field,
      columnName: mappedColumnName,
      descriptor,
      ...ifDefined('defaultValue', fieldDefaultValue),
      ...ifDefined('executionDefaults', fieldExecutionDefaults),
      isId: Boolean(idAttribute) || Boolean(presetContributions?.id),
      isUnique: Boolean(uniqueAttribute) || Boolean(presetContributions?.unique),
      ...ifDefined('idName', idName),
      ...ifDefined('uniqueName', uniqueName),
      ...ifDefined('many', isListField ? (true as const) : undefined),
      ...ifDefined('valueObjectTypeName', isValueObjectField ? field.typeName : undefined),
      ...ifDefined('scalarCodecId', scalarCodecId),
    });
  }

  return resolvedFields;
}

export function buildModelMappings(
  models: readonly PslModel[],
  diagnostics: ContractSourceDiagnostic[],
  sourceId: string,
): Map<string, ModelNameMapping> {
  const result = new Map<string, ModelNameMapping>();
  for (const model of models) {
    const mapAttribute = getAttribute(model.attributes, 'map');
    const tableName = parseMapName({
      attribute: mapAttribute,
      defaultValue: lowerFirst(model.name),
      sourceId,
      diagnostics,
      entityLabel: `Model "${model.name}"`,
      span: model.span,
    });
    const fieldColumns = new Map<string, string>();
    for (const field of model.fields) {
      const fieldMapAttribute = getAttribute(field.attributes, 'map');
      const columnName = parseMapName({
        attribute: fieldMapAttribute,
        defaultValue: field.name,
        sourceId,
        diagnostics,
        entityLabel: `Field "${model.name}.${field.name}"`,
        span: field.span,
      });
      fieldColumns.set(field.name, columnName);
    }
    result.set(model.name, {
      model,
      tableName,
      fieldColumns,
    });
  }
  return result;
}
