import type { ExecutionPlan } from '@prisma-next/contract/types';
import { instantiateExecutionStack } from '@prisma-next/framework-components/execution';
import type { AsyncIterableResult } from '@prisma-next/runtime-executor';
import { describe, expect, it } from 'vitest';
import type { Runtime } from '../src/exports';
import { createRuntime, createSqlExecutionStack } from '../src/exports';
import {
  createStubAdapter,
  createTestAdapterDescriptor,
  createTestContext,
  createTestContract,
  createTestTargetDescriptor,
} from './utils';

class MockDriver {
  private rows: ReadonlyArray<Record<string, unknown>> = [];

  setRows(rows: ReadonlyArray<Record<string, unknown>>): void {
    this.rows = rows;
  }

  async query<Row = Record<string, unknown>>(
    _sql: string,
    _params?: readonly unknown[],
  ): Promise<{ rows: ReadonlyArray<Row> }> {
    return { rows: [] };
  }

  async *execute<Row = Record<string, unknown>>(_options: {
    sql: string;
    params: readonly unknown[];
  }): AsyncIterable<Row> {
    for (const row of this.rows) {
      yield row as Row;
    }
  }

  async acquireConnection(): Promise<never> {
    throw new Error('Not implemented in mock');
  }

  async connect(): Promise<void> {}

  async close(): Promise<void> {}
}

const fixtureContract = createTestContract({
  targetFamily: 'sql',
  target: 'postgres',
  storageHash: 'test-hash',
  profileHash: 'test-profile-hash',
  storage: {
    tables: {
      user: {
        columns: {
          id: { nativeType: 'int4', codecId: 'pg/int4@1', nullable: false },
          email: { nativeType: 'text', codecId: 'pg/text@1', nullable: false },
        },
        uniques: [],
        indexes: [],
        foreignKeys: [],
      },
    },
  },
  models: {},
});

function createTestRuntime(mockDriver: MockDriver): Runtime {
  const adapter = createStubAdapter();
  const stack = createSqlExecutionStack({
    target: createTestTargetDescriptor(),
    adapter: createTestAdapterDescriptor(adapter),
    extensionPacks: [],
  });
  const stackInstance = instantiateExecutionStack(stack);
  const context = createTestContext(fixtureContract, adapter);
  return createRuntime({
    stackInstance,
    context,
    driver: mockDriver,
    verify: { mode: 'onFirstUse', requireMarker: false },
  });
}

describe('SqlRuntime AsyncIterableResult integration', () => {
  it('returns AsyncIterableResult from execute', async () => {
    const driver = new MockDriver();
    driver.setRows([
      { id: 1, email: 'test1@example.com' },
      { id: 2, email: 'test2@example.com' },
    ]);
    const runtime = createTestRuntime(driver);

    const plan: ExecutionPlan<{ id: number; email: string }> = {
      sql: 'SELECT id, email FROM "user" ORDER BY id',
      params: [],
      meta: {
        target: 'postgres',
        targetFamily: 'sql',
        storageHash: 'test-hash',
        lane: 'sql',
        paramDescriptors: [],
      },
    };

    const result = runtime.execute(plan);

    expect(result).toBeInstanceOf(Object);
    expect(typeof result.toArray).toBe('function');
    expect(typeof result[Symbol.asyncIterator]).toBe('function');

    await runtime.close();
  });

  it('preserves type information', async () => {
    const driver = new MockDriver();
    driver.setRows([{ id: 1, email: 'test@example.com' }]);
    const runtime = createTestRuntime(driver);

    const plan: ExecutionPlan<{ id: number; email: string }> = {
      sql: 'SELECT id, email FROM "user" LIMIT 1',
      params: [],
      meta: {
        target: 'postgres',
        targetFamily: 'sql',
        storageHash: 'test-hash',
        lane: 'sql',
        paramDescriptors: [],
      },
    };

    const result: AsyncIterableResult<{ id: number; email: string }> = runtime.execute(plan);
    const rows = await result.toArray();

    expect(rows.length).toBe(1);
    expect(typeof rows[0]!.id).toBe('number');
    expect(typeof rows[0]!.email).toBe('string');

    await runtime.close();
  });
});
