import type { Contract } from '@prisma-next/contract/types';
import type { SqlStorage } from '@prisma-next/sql-contract/types';
import type { Adapter, AnyQueryAst, LoweredStatement } from '@prisma-next/sql-relational-core/ast';
import type { SqlExecutionPlan, SqlQueryPlan } from '@prisma-next/sql-relational-core/plan';

/**
 * Lowers a SQL query plan to an executable Plan by calling the adapter's lower method.
 *
 * @param adapter - Adapter to lower AST to SQL
 * @param contract - Contract for lowering context
 * @param queryPlan - SQL query plan from a lane (contains AST, params, meta, but no SQL)
 * @returns Fully executable Plan with SQL string
 */
export function lowerSqlPlan<Row>(
  adapter: Adapter<AnyQueryAst, Contract<SqlStorage>, LoweredStatement>,
  contract: Contract<SqlStorage>,
  queryPlan: SqlQueryPlan<Row>,
): SqlExecutionPlan<Row> {
  const lowered = adapter.lower(queryPlan.ast, {
    contract,
    params: queryPlan.params,
  });

  return Object.freeze({
    sql: lowered.sql,
    params: lowered.params ?? queryPlan.params,
    ast: queryPlan.ast,
    meta: queryPlan.meta,
  });
}
