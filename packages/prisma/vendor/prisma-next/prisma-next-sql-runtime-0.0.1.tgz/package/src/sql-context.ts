import type { Contract, ExecutionMutationDefaultValue } from '@prisma-next/contract/types';
import type { CodecDescriptor } from '@prisma-next/framework-components/codec';
import { synthesizeNonParameterizedDescriptor } from '@prisma-next/framework-components/codec';
import type { ComponentDescriptor } from '@prisma-next/framework-components/components';
import { checkContractComponentRequirements } from '@prisma-next/framework-components/components';
import {
  createExecutionStack,
  type ExecutionStack,
  type RuntimeAdapterDescriptor,
  type RuntimeAdapterInstance,
  type RuntimeDriverDescriptor,
  type RuntimeDriverInstance,
  type RuntimeExtensionDescriptor,
  type RuntimeExtensionInstance,
  type RuntimeTargetDescriptor,
  type RuntimeTargetInstance,
} from '@prisma-next/framework-components/execution';
import { runtimeError } from '@prisma-next/framework-components/runtime';
import type { SqlStorage } from '@prisma-next/sql-contract/types';
import {
  createSqlOperationRegistry,
  type SqlOperationDescriptor,
} from '@prisma-next/sql-operations';
import type {
  Adapter,
  AnyQueryAst,
  Codec,
  CodecRegistry,
  ContractCodecRegistry,
  LoweredStatement,
  SqlCodecInstanceContext,
  SqlDriver,
} from '@prisma-next/sql-relational-core/ast';
import { createCodecRegistry } from '@prisma-next/sql-relational-core/ast';
import type {
  AppliedMutationDefault,
  CodecDescriptorRegistry,
  ExecutionContext,
  JsonSchemaValidateFn,
  JsonSchemaValidatorRegistry,
  MutationDefaultsOptions,
  TypeHelperRegistry,
} from '@prisma-next/sql-relational-core/query-lane-context';

/**
 * Runtime parameterized codec descriptor.
 *
 * The unified `CodecDescriptor<P>` shape applied to parameterized codecs
 * — `paramsSchema: StandardSchemaV1<P>` for JSON-boundary validation,
 * `factory: (P) => (CodecInstanceContext) => Codec` for the curried higher-order codec.
 * The factory is called once per `storage.types` instance (or once per
 * inline-`typeParams` column); per-instance state lives in the closure.
 *
 * Codec-registry-unification spec § Decision.
 */
export type RuntimeParameterizedCodecDescriptor<P = Record<string, unknown>> = CodecDescriptor<P>;

export interface SqlStaticContributions {
  readonly codecs: () => CodecRegistry;
  // biome-ignore lint/suspicious/noExplicitAny: needed for covariance with concrete descriptor types
  readonly parameterizedCodecs: () => ReadonlyArray<RuntimeParameterizedCodecDescriptor<any>>;
  readonly queryOperations?: () => ReadonlyArray<SqlOperationDescriptor>;
  readonly mutationDefaultGenerators?: () => ReadonlyArray<RuntimeMutationDefaultGenerator>;
}

export interface RuntimeMutationDefaultGenerator {
  readonly id: string;
  readonly generate: (params?: Record<string, unknown>) => unknown;
  /**
   * When `true`, this generator's `onUpdate` value still fires for empty
   * update payloads. Default `false` preserves Prisma's `@updatedAt`
   * semantics (RD2): no write ⇒ no advance. Future generators that need
   * sentinel-write behavior (e.g. `revisionBump`, audit-trail markers)
   * opt in here.
   */
  readonly applyOnEmptyUpdate?: boolean;
  /**
   * When `true`, a single ORM operation that lowers to one bulk mutation
   * (e.g. `createMany` over many rows) reuses one generated value across
   * every row that needs this default. Callers signal a bulk scope by
   * passing a fresh `acrossRowsCache` to `applyMutationDefaults` and reusing it
   * across the per-row invocations. Default `false` keeps each invocation
   * independent (right for per-row identifiers like `cuid`).
   */
  readonly stableAcrossRows?: boolean;
}

export interface SqlRuntimeTargetDescriptor<
  TTargetId extends string = string,
  TTargetInstance extends RuntimeTargetInstance<'sql', TTargetId> = RuntimeTargetInstance<
    'sql',
    TTargetId
  >,
> extends RuntimeTargetDescriptor<'sql', TTargetId, TTargetInstance>,
    SqlStaticContributions {}

export interface SqlRuntimeAdapterDescriptor<
  TTargetId extends string = string,
  TAdapterInstance extends RuntimeAdapterInstance<
    'sql',
    TTargetId
  > = SqlRuntimeAdapterInstance<TTargetId>,
> extends RuntimeAdapterDescriptor<'sql', TTargetId, TAdapterInstance>,
    SqlStaticContributions {}

export interface SqlRuntimeExtensionDescriptor<TTargetId extends string = string>
  extends RuntimeExtensionDescriptor<'sql', TTargetId, SqlRuntimeExtensionInstance<TTargetId>>,
    SqlStaticContributions {
  create(): SqlRuntimeExtensionInstance<TTargetId>;
}

export interface SqlExecutionStack<TTargetId extends string = string> {
  readonly target: SqlRuntimeTargetDescriptor<TTargetId>;
  readonly adapter: SqlRuntimeAdapterDescriptor<TTargetId>;
  readonly extensionPacks: readonly SqlRuntimeExtensionDescriptor<TTargetId>[];
}

export type SqlExecutionStackWithDriver<TTargetId extends string = string> = Omit<
  ExecutionStack<
    'sql',
    TTargetId,
    SqlRuntimeAdapterInstance<TTargetId>,
    SqlRuntimeDriverInstance<TTargetId>,
    SqlRuntimeExtensionInstance<TTargetId>
  >,
  'target' | 'adapter' | 'driver' | 'extensionPacks'
> & {
  readonly target: SqlRuntimeTargetDescriptor<TTargetId>;
  readonly adapter: SqlRuntimeAdapterDescriptor<TTargetId, SqlRuntimeAdapterInstance<TTargetId>>;
  readonly driver:
    | RuntimeDriverDescriptor<'sql', TTargetId, unknown, SqlRuntimeDriverInstance<TTargetId>>
    | undefined;
  readonly extensionPacks: readonly SqlRuntimeExtensionDescriptor<TTargetId>[];
};

export interface SqlRuntimeExtensionInstance<TTargetId extends string>
  extends RuntimeExtensionInstance<'sql', TTargetId> {}

export type SqlRuntimeAdapterInstance<TTargetId extends string = string> = RuntimeAdapterInstance<
  'sql',
  TTargetId
> &
  Adapter<AnyQueryAst, Contract<SqlStorage>, LoweredStatement>;

/**
 * NOTE: Binding type is intentionally erased to unknown at this shared runtime layer.
 * Target clients (for example `postgres()`) validate and construct the concrete binding
 * before calling `driver.connect(binding)`, which keeps runtime behavior safe today.
 * A future follow-up can preserve TBinding through stack/context generics end-to-end.
 */
export type SqlRuntimeDriverInstance<TTargetId extends string = string> = RuntimeDriverInstance<
  'sql',
  TTargetId
> &
  SqlDriver<unknown>;

export function createSqlExecutionStack<TTargetId extends string>(options: {
  readonly target: SqlRuntimeTargetDescriptor<TTargetId>;
  readonly adapter: SqlRuntimeAdapterDescriptor<TTargetId>;
  readonly driver?:
    | RuntimeDriverDescriptor<'sql', TTargetId, unknown, SqlRuntimeDriverInstance<TTargetId>>
    | undefined;
  readonly extensionPacks?: readonly SqlRuntimeExtensionDescriptor<TTargetId>[] | undefined;
}): SqlExecutionStackWithDriver<TTargetId> {
  return createExecutionStack({
    target: options.target,
    adapter: options.adapter,
    driver: options.driver,
    extensionPacks: options.extensionPacks,
  });
}

export type { ExecutionContext, JsonSchemaValidatorRegistry, TypeHelperRegistry };

export function assertExecutionStackContractRequirements(
  contract: Contract<SqlStorage>,
  stack: SqlExecutionStack,
): void {
  const providedComponentIds = new Set<string>([
    stack.target.id,
    stack.adapter.id,
    ...stack.extensionPacks.map((pack) => pack.id),
  ]);

  const result = checkContractComponentRequirements({
    contract,
    expectedTargetFamily: 'sql',
    expectedTargetId: stack.target.targetId,
    providedComponentIds,
  });

  if (result.familyMismatch) {
    throw runtimeError(
      'RUNTIME.CONTRACT_FAMILY_MISMATCH',
      `Contract target family '${result.familyMismatch.actual}' does not match runtime family '${result.familyMismatch.expected}'.`,
      {
        actual: result.familyMismatch.actual,
        expected: result.familyMismatch.expected,
      },
    );
  }

  if (result.targetMismatch) {
    throw runtimeError(
      'RUNTIME.CONTRACT_TARGET_MISMATCH',
      `Contract target '${result.targetMismatch.actual}' does not match runtime target descriptor '${result.targetMismatch.expected}'.`,
      {
        actual: result.targetMismatch.actual,
        expected: result.targetMismatch.expected,
      },
    );
  }

  if (result.missingExtensionPackIds.length > 0) {
    const packIds = result.missingExtensionPackIds;
    const packList = packIds.map((id) => `'${id}'`).join(', ');
    throw runtimeError(
      'RUNTIME.MISSING_EXTENSION_PACK',
      `Contract requires extension pack(s) ${packList}, but runtime descriptors do not provide matching component(s).`,
      { packIds },
    );
  }
}

function validateTypeParams(
  typeParams: Record<string, unknown>,
  codecDescriptor: RuntimeParameterizedCodecDescriptor,
  context: { typeName?: string; tableName?: string; columnName?: string },
): Record<string, unknown> {
  const result = codecDescriptor.paramsSchema['~standard'].validate(typeParams);
  if (result instanceof Promise) {
    throw runtimeError(
      'RUNTIME.TYPE_PARAMS_INVALID',
      `paramsSchema for codec '${codecDescriptor.codecId}' returned a Promise; runtime validation requires a synchronous Standard Schema validator.`,
      { ...context, codecId: codecDescriptor.codecId, typeParams },
    );
  }
  if (result.issues) {
    const messages = result.issues.map((issue) => issue.message).join('; ');
    const locationInfo = context.typeName
      ? `type '${context.typeName}'`
      : `column '${context.tableName}.${context.columnName}'`;
    throw runtimeError(
      'RUNTIME.TYPE_PARAMS_INVALID',
      `Invalid typeParams for ${locationInfo} (codecId: ${codecDescriptor.codecId}): ${messages}`,
      { ...context, codecId: codecDescriptor.codecId, typeParams },
    );
  }
  return result.value as Record<string, unknown>;
}

function collectParameterizedCodecDescriptors(
  contributors: ReadonlyArray<SqlStaticContributions>,
): Map<string, RuntimeParameterizedCodecDescriptor> {
  const descriptors = new Map<string, RuntimeParameterizedCodecDescriptor>();

  for (const contributor of contributors) {
    for (const descriptor of contributor.parameterizedCodecs()) {
      if (descriptors.has(descriptor.codecId)) {
        throw runtimeError(
          'RUNTIME.DUPLICATE_PARAMETERIZED_CODEC',
          `Duplicate parameterized codec descriptor for codecId '${descriptor.codecId}'.`,
          { codecId: descriptor.codecId },
        );
      }
      descriptors.set(descriptor.codecId, descriptor);
    }
  }

  return descriptors;
}

/**
 * Build the unified descriptor map. Combines parameterized descriptors
 * (which already ship as `CodecDescriptor`s) with synthesized descriptors
 * for non-parameterized codecs registered through the legacy `codecs:`
 * slot. Codec ids that ship a parameterized descriptor take precedence —
 * even when the legacy registry registers a representative codec under
 * the same id, the parameterized descriptor is the authoritative source.
 *
 * Codec-registry-unification spec § Decision: every codec resolves
 * through one descriptor map; reads are non-branching.
 */
function buildCodecDescriptorRegistry(
  codecRegistry: CodecRegistry,
  parameterizedDescriptors: Map<string, RuntimeParameterizedCodecDescriptor>,
): CodecDescriptorRegistry {
  type AnyDescriptor = CodecDescriptor<unknown>;
  const byId = new Map<string, AnyDescriptor>();
  const byTargetType = new Map<string, Array<AnyDescriptor>>();

  function registerInIndices(descriptor: AnyDescriptor): void {
    byId.set(descriptor.codecId, descriptor);
    for (const targetType of descriptor.targetTypes) {
      const list = byTargetType.get(targetType);
      if (list) {
        list.push(descriptor);
      } else {
        byTargetType.set(targetType, [descriptor]);
      }
    }
  }

  // The descriptor map is heterogeneous in `P` — each codec id has its own
  // params shape. The public `CodecDescriptorRegistry` interface widens to
  // `CodecDescriptor<unknown>` and consumers narrow per codec id at the
  // call site (the descriptor's `paramsSchema` validates JSON-sourced
  // params before the factory ever sees them, so the runtime narrow is
  // safe). The cast at registration goes through `unknown` because
  // `CodecDescriptor<P>` is invariant in `P` (the `factory` and
  // `renderOutputType` slots use `P` contravariantly).
  for (const descriptor of parameterizedDescriptors.values()) {
    registerInIndices(descriptor as unknown as AnyDescriptor);
  }

  for (const codec of codecRegistry.values()) {
    if (byId.has(codec.id)) continue;
    registerInIndices(synthesizeNonParameterizedDescriptor(codec) as unknown as AnyDescriptor);
  }

  return {
    descriptorFor(codecId: string): AnyDescriptor | undefined {
      return byId.get(codecId);
    },
    *values(): IterableIterator<AnyDescriptor> {
      yield* byId.values();
    },
    byTargetType(targetType: string): readonly AnyDescriptor[] {
      return byTargetType.get(targetType) ?? Object.freeze([]);
    },
  };
}

function collectTypeRefSites(
  storage: SqlStorage,
): Map<string, Array<{ readonly table: string; readonly column: string }>> {
  const sites = new Map<string, Array<{ readonly table: string; readonly column: string }>>();
  for (const [tableName, table] of Object.entries(storage.tables)) {
    for (const [columnName, column] of Object.entries(table.columns)) {
      if (typeof column.typeRef !== 'string') continue;
      const list = sites.get(column.typeRef);
      const entry = { table: tableName, column: columnName };
      if (list) {
        list.push(entry);
      } else {
        sites.set(column.typeRef, [entry]);
      }
    }
  }
  return sites;
}

function initializeTypeHelpers(
  storage: SqlStorage,
  codecDescriptors: Map<string, RuntimeParameterizedCodecDescriptor>,
): TypeHelperRegistry {
  const helpers: TypeHelperRegistry = {};
  const storageTypes = storage.types;

  if (!storageTypes) {
    return helpers;
  }

  const typeRefSites = collectTypeRefSites(storage);

  for (const [typeName, typeInstance] of Object.entries(storageTypes)) {
    const descriptor = codecDescriptors.get(typeInstance.codecId);

    if (!descriptor) {
      // No parameterized descriptor for this codec id — store the raw
      // type instance for callers that need typeParams metadata.
      helpers[typeName] = typeInstance;
      continue;
    }

    const validatedParams = validateTypeParams(typeInstance.typeParams, descriptor, {
      typeName,
    });

    const usedAt = typeRefSites.get(typeName) ?? [];
    const ctx: SqlCodecInstanceContext = { name: typeName, usedAt };
    helpers[typeName] = descriptor.factory(validatedParams)(ctx);
  }

  return helpers;
}

function validateColumnTypeParams(
  storage: SqlStorage,
  codecDescriptors: Map<string, RuntimeParameterizedCodecDescriptor>,
): void {
  for (const [tableName, table] of Object.entries(storage.tables)) {
    for (const [columnName, column] of Object.entries(table.columns)) {
      if (column.typeParams) {
        const descriptor = codecDescriptors.get(column.codecId);
        if (descriptor) {
          validateTypeParams(column.typeParams, descriptor, { tableName, columnName });
        }
      }
    }
  }
}

/**
 * View of a codec that exposes a per-instance JSON-schema `validate`
 * function. Codecs declare this contract by including the
 * `'json-validator'` `CodecTrait` in their `traits` array; the trait is
 * the gate that lets `extractValidator` resolve from structurally-typed
 * `unknown` to this typed view.
 */
type JsonValidatorCodec = {
  readonly traits?: ReadonlyArray<unknown>;
  readonly validate: JsonSchemaValidateFn;
};

function hasJsonValidatorTrait(candidate: unknown): candidate is JsonValidatorCodec {
  if (candidate === null || typeof candidate !== 'object') return false;
  const traits = (candidate as { readonly traits?: unknown }).traits;
  if (!Array.isArray(traits)) return false;
  if (!traits.includes('json-validator')) return false;
  const validate = (candidate as { readonly validate?: unknown }).validate;
  return typeof validate === 'function';
}

function extractValidator(candidate: unknown): JsonSchemaValidateFn | undefined {
  return hasJsonValidatorTrait(candidate) ? candidate.validate : undefined;
}

function isResolvedCodec(candidate: unknown): candidate is Codec {
  return (
    candidate !== null &&
    typeof candidate === 'object' &&
    'id' in candidate &&
    'decode' in candidate
  );
}

/**
 * Walk the contract's `storage.tables[].columns[]` and resolve each
 * column to a `Codec` through the unified descriptor map. Per-instance
 * behavior:
 *
 * - **typeRef columns**: reuse the resolved codec materialized once by
 *   `initializeTypeHelpers` for the `storage.types` entry. Multiple
 *   columns sharing one typeRef share one codec instance.
 * - **inline-typeParams columns**: call `descriptor.factory(typeParams)
 *   (ctx)` once per column (per-column anonymous instance).
 * - **non-parameterized columns**: call `descriptor.factory()(ctx)`
 *   once. The synthesized descriptor's factory is constant — every call
 *   returns the same shared codec instance — so columns sharing a non-
 *   parameterized codec id share one resolved codec without explicit
 *   caching.
 *
 * Combines what `initializeTypeHelpers` (named-instance walk) and the
 * old `buildJsonSchemaValidatorRegistry` (per-column walk) used to do
 * separately: one walk over all columns, one resolved codec per column,
 * one trait-gated validator extraction per column. The result drives
 * both the dispatch registry (`ContractCodecRegistry.forColumn`) and the
 * validator registry.
 *
 * Codec-registry-unification spec § AC-4: every column resolves through
 * one descriptor map without branching on parameterization.
 */
function buildContractCodecRegistry(
  contract: Contract<SqlStorage>,
  codecDescriptors: CodecDescriptorRegistry,
  legacyCodecRegistry: CodecRegistry,
  types: TypeHelperRegistry,
  parameterizedDescriptors: Map<string, RuntimeParameterizedCodecDescriptor>,
): {
  readonly registry: ContractCodecRegistry;
  readonly jsonValidators: JsonSchemaValidatorRegistry | undefined;
} {
  const byColumn = new Map<string, Codec>();
  const byCodecId = new Map<string, Codec>();
  // Codec ids whose `byCodecId` entry is ambiguous — multiple distinct
  // resolved instances landed under the same parameterized codec id (e.g.
  // `Vector<1024>` and `Vector<1536>` both registering under
  // `pg/vector@1`). The encode-side `forCodecId` fallback rejects these
  // ids so a DSL-param without a column ref cannot silently bind to the
  // wrong instance. Retires when AC-5's `ParamRef.refs` plumbing lands
  // (TML-2357).
  const ambiguousCodecIds = new Set<string>();
  const validators = new Map<string, JsonSchemaValidateFn>();

  for (const [tableName, table] of Object.entries(contract.storage.tables)) {
    for (const [columnName, column] of Object.entries(table.columns)) {
      const columnKey = `${tableName}.${columnName}`;
      const descriptor = codecDescriptors.descriptorFor(column.codecId);

      let resolvedCodec: Codec | undefined;

      if (descriptor) {
        const isParameterized = parameterizedDescriptors.has(column.codecId);

        if (column.typeRef) {
          // The named instance was already materialized once by
          // `initializeTypeHelpers`; reuse it so multiple columns sharing
          // the same typeRef share one codec instance (and any per-
          // instance helper state on it).
          const helper = types[column.typeRef];
          if (isResolvedCodec(helper)) {
            resolvedCodec = helper;
          }
        } else if (column.typeParams && isParameterized) {
          const parameterizedDescriptor = parameterizedDescriptors.get(column.codecId);
          if (parameterizedDescriptor) {
            const validatedParams = validateTypeParams(column.typeParams, parameterizedDescriptor, {
              tableName,
              columnName,
            });
            const ctx: SqlCodecInstanceContext = {
              name: `<anon:${tableName}.${columnName}>`,
              usedAt: [{ table: tableName, column: columnName }],
            };
            resolvedCodec = parameterizedDescriptor.factory(validatedParams)(ctx);
          }
        } else if (!isParameterized) {
          // Non-parameterized column. Cache the resolved codec by codec
          // id — the synthesized descriptor's factory is constant for
          // non-parameterized codecs, so columns sharing this codec id
          // share one resolved instance.
          let cached = byCodecId.get(column.codecId);
          if (!cached) {
            const ctx: SqlCodecInstanceContext = {
              name: `<shared:${column.codecId}>`,
              usedAt: [{ table: tableName, column: columnName }],
            };
            // `synthesizeNonParameterizedDescriptor` produces a
            // `CodecDescriptor<void>` whose factory ignores its params
            // and ctx; the runtime's `void` value is `undefined`. The
            // structural cast goes through `unknown` to satisfy the
            // heterogeneous-`P` registry boundary (the factory's
            // declared `P` is `any` here; the consumer narrows per
            // codec id). The cast narrows the descriptor's
            // family-agnostic `CodecInstanceContext` slot to the SQL
            // `SqlCodecInstanceContext` we pass at this call site —
            // function-argument contravariance makes the narrow safe
            // (a callee that accepts the base will also accept the
            // SQL extension). Per spec § Non-functional constraints.
            const voidFactory = descriptor.factory as unknown as (
              params: undefined,
            ) => (ctx: SqlCodecInstanceContext) => Codec;
            cached = voidFactory(undefined)(ctx);
            byCodecId.set(column.codecId, cached);
          }
          resolvedCodec = cached;
        }
        // else: parameterized codec id with no typeRef and no typeParams
        // — this is the legitimate "undimensioned" form for codecs that
        // ship a no-params column variant alongside a parameterized one
        // (e.g. pgvector's `vectorColumn` vs. `vector(N)`). Leave
        // `resolvedCodec` undefined; encode/decode for this column flows
        // through `forCodecId` (the AC-5-deferred carve-out documented
        // in `relational-core/src/ast/codec-types.ts`). The fallback
        // works for these cases because their wire format is
        // params-independent (vector formats `[v1,v2,...]` regardless
        // of declared length).
      }

      if (resolvedCodec) {
        byColumn.set(columnKey, resolvedCodec);
        const validate = extractValidator(resolvedCodec);
        if (validate) {
          validators.set(columnKey, validate);
        }
        const existing = byCodecId.get(column.codecId);
        if (existing === undefined) {
          byCodecId.set(column.codecId, resolvedCodec);
        } else if (existing !== resolvedCodec && parameterizedDescriptors.has(column.codecId)) {
          ambiguousCodecIds.add(column.codecId);
        }
      }
    }
  }

  const registry: ContractCodecRegistry = {
    forColumn(table, column) {
      return byColumn.get(`${table}.${column}`);
    },
    forCodecId(codecId) {
      // Codec-id-only fallback for sites without a column ref (encode-
      // side DSL params whose `ParamRef.refs` isn't populated). Prefer
      // the contract-walk-derived shared codec; fall back to the legacy
      // `codecRegistry.get` for parameterized codec ids whose contracts
      // don't have a typeRef/typeParams column the walk could resolve
      // through. The legacy fallback retires once `ParamRef.refs` is
      // threaded everywhere (TML-2357).
      //
      // Reject ambiguous parameterized fallbacks: if the contract walk
      // resolved more than one distinct codec instance under this id
      // (e.g. multiple vector dimensions, multiple arktype-json
      // schemas), the codec-id-keyed lookup cannot honor the call site
      // — fail fast rather than bind to whichever instance happened to
      // land first.
      if (ambiguousCodecIds.has(codecId)) {
        throw runtimeError(
          'RUNTIME.TYPE_PARAMS_INVALID',
          `Codec '${codecId}' resolves to multiple parameterized instances; column-aware dispatch is required.`,
          { codecId },
        );
      }
      return byCodecId.get(codecId) ?? legacyCodecRegistry.get(codecId);
    },
  };

  const jsonValidators: JsonSchemaValidatorRegistry | undefined =
    validators.size > 0
      ? {
          get: (key: string) => validators.get(key),
          size: validators.size,
        }
      : undefined;

  return { registry, jsonValidators };
}

function assertMutationDefaultGeneratorsAvailable(
  contract: Contract<SqlStorage>,
  generatorRegistry: ReadonlyMap<string, RuntimeMutationDefaultGenerator>,
): void {
  const defaults = contract.execution?.mutations.defaults ?? [];
  if (defaults.length === 0) return;

  const missing = new Set<string>();
  for (const mutationDefault of defaults) {
    for (const phase of [mutationDefault.onCreate, mutationDefault.onUpdate]) {
      if (!phase) continue;
      if (phase.kind === 'generator' && !generatorRegistry.has(phase.id)) {
        missing.add(phase.id);
      }
    }
  }

  if (missing.size === 0) return;

  const ids = Array.from(missing);
  const idList = ids.map((id) => `'${id}'`).join(', ');
  throw runtimeError(
    'RUNTIME.MISSING_MUTATION_DEFAULT_GENERATOR',
    `Contract requires mutation default generator(s) ${idList}, but no runtime component provides them.`,
    { ids },
  );
}

function collectMutationDefaultGenerators(
  contributors: ReadonlyArray<SqlStaticContributions & { readonly id: string }>,
): ReadonlyMap<string, RuntimeMutationDefaultGenerator> {
  const generators = new Map<string, RuntimeMutationDefaultGenerator>();
  const owners = new Map<string, string>();

  for (const contributor of contributors) {
    const nextGenerators = contributor.mutationDefaultGenerators?.() ?? [];
    for (const generator of nextGenerators) {
      const existingOwner = owners.get(generator.id);
      if (existingOwner !== undefined) {
        throw runtimeError(
          'RUNTIME.DUPLICATE_MUTATION_DEFAULT_GENERATOR',
          `Duplicate mutation default generator '${generator.id}'.`,
          {
            id: generator.id,
            existingOwner,
            incomingOwner: contributor.id,
          },
        );
      }
      generators.set(generator.id, generator);
      owners.set(generator.id, contributor.id);
    }
  }

  return generators;
}

function computeExecutionDefaultValue(
  spec: ExecutionMutationDefaultValue,
  generatorRegistry: ReadonlyMap<string, RuntimeMutationDefaultGenerator>,
): unknown {
  switch (spec.kind) {
    case 'generator': {
      const generator = generatorRegistry.get(spec.id);
      if (!generator) {
        throw runtimeError(
          'RUNTIME.MUTATION_DEFAULT_GENERATOR_MISSING',
          `Contract references mutation default generator '${spec.id}' but no runtime component provides it.`,
          {
            id: spec.id,
          },
        );
      }
      // nosemgrep: javascript.express.security.express-wkhtml-injection.express-wkhtmltoimage-injection
      return generator.generate(spec.params);
    }
  }
}

function applyMutationDefaults(
  contract: Contract<SqlStorage>,
  generatorRegistry: ReadonlyMap<string, RuntimeMutationDefaultGenerator>,
  options: MutationDefaultsOptions,
): ReadonlyArray<AppliedMutationDefault> {
  const defaults = contract.execution?.mutations.defaults ?? [];
  if (defaults.length === 0) {
    return [];
  }

  const isEmptyUpdate = options.op === 'update' && Object.keys(options.values).length === 0;

  const applied: AppliedMutationDefault[] = [];
  const appliedColumns = new Set<string>();

  for (const mutationDefault of defaults) {
    if (mutationDefault.ref.table !== options.table) {
      continue;
    }

    const defaultSpec =
      options.op === 'create' ? mutationDefault.onCreate : mutationDefault.onUpdate;
    if (!defaultSpec) {
      continue;
    }

    // RD2: empty update payloads skip onUpdate defaults by default — no
    // write means no `@updatedAt` advance. Generators that need sentinel-
    // write semantics opt in via `applyOnEmptyUpdate: true`.
    if (isEmptyUpdate && defaultSpec.kind === 'generator') {
      const generator = generatorRegistry.get(defaultSpec.id);
      if (!generator?.applyOnEmptyUpdate) {
        continue;
      }
    }

    const columnName = mutationDefault.ref.column;
    if (Object.hasOwn(options.values, columnName) || appliedColumns.has(columnName)) {
      continue;
    }

    applied.push({
      column: columnName,
      value: resolveStableAcrossRowsValue(
        defaultSpec,
        columnName,
        generatorRegistry,
        options.acrossRowsCache,
      ),
    });
    appliedColumns.add(columnName);
  }

  return applied;
}

function resolveStableAcrossRowsValue(
  spec: ExecutionMutationDefaultValue,
  columnName: string,
  generatorRegistry: ReadonlyMap<string, RuntimeMutationDefaultGenerator>,
  acrossRowsCache: Map<string, unknown> | undefined,
): unknown {
  if (!acrossRowsCache || spec.kind !== 'generator') {
    return computeExecutionDefaultValue(spec, generatorRegistry);
  }
  const generator = generatorRegistry.get(spec.id);
  if (!generator?.stableAcrossRows) {
    return computeExecutionDefaultValue(spec, generatorRegistry);
  }
  if (acrossRowsCache.has(columnName)) {
    return acrossRowsCache.get(columnName);
  }
  const value = computeExecutionDefaultValue(spec, generatorRegistry);
  acrossRowsCache.set(columnName, value);
  return value;
}

export function createExecutionContext<
  TContract extends Contract<SqlStorage> = Contract<SqlStorage>,
  TTargetId extends string = string,
>(options: {
  readonly contract: TContract;
  readonly stack: SqlExecutionStack<TTargetId>;
}): ExecutionContext<TContract> {
  const { contract, stack } = options;

  assertExecutionStackContractRequirements(contract, stack);

  const codecRegistry = createCodecRegistry();

  const contributors: Array<SqlStaticContributions & ComponentDescriptor<string>> = [
    stack.target,
    stack.adapter,
    ...stack.extensionPacks,
  ];

  for (const contributor of contributors) {
    for (const c of contributor.codecs().values()) {
      codecRegistry.register(c);
    }
  }

  const queryOperationRegistry = createSqlOperationRegistry();
  for (const contributor of contributors) {
    for (const op of contributor.queryOperations?.() ?? []) {
      queryOperationRegistry.register(op);
    }
  }

  const parameterizedCodecDescriptors = collectParameterizedCodecDescriptors(contributors);
  const codecDescriptors = buildCodecDescriptorRegistry(
    codecRegistry,
    parameterizedCodecDescriptors,
  );
  const mutationDefaultGeneratorRegistry = collectMutationDefaultGenerators(contributors);
  assertMutationDefaultGeneratorsAvailable(contract, mutationDefaultGeneratorRegistry);

  if (parameterizedCodecDescriptors.size > 0) {
    validateColumnTypeParams(contract.storage, parameterizedCodecDescriptors);
  }

  const types = initializeTypeHelpers(contract.storage, parameterizedCodecDescriptors);

  const { registry: contractCodecs, jsonValidators: jsonSchemaValidators } =
    buildContractCodecRegistry(
      contract,
      codecDescriptors,
      codecRegistry,
      types,
      parameterizedCodecDescriptors,
    );

  return {
    contract,
    codecs: codecRegistry,
    contractCodecs,
    codecDescriptors,
    queryOperations: queryOperationRegistry,
    types,
    ...(jsonSchemaValidators ? { jsonSchemaValidators } : {}),
    applyMutationDefaults: (options) =>
      applyMutationDefaults(contract, mutationDefaultGeneratorRegistry, options),
  };
}
