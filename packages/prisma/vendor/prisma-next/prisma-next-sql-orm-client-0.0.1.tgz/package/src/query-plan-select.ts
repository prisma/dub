import type { Contract } from '@prisma-next/contract/types';
import type { SqlStorage } from '@prisma-next/sql-contract/types';
import {
  AndExpr,
  type AnyExpression,
  type AstRewriter,
  BinaryExpr,
  type BinaryOp,
  ColumnRef,
  DerivedTableSource,
  EqColJoinOn,
  JoinAst,
  JsonArrayAggExpr,
  JsonObjectExpr,
  ListExpression,
  LiteralExpr,
  OrderByItem,
  OrExpr,
  ProjectionItem,
  SelectAst,
  SubqueryExpr,
  TableSource,
} from '@prisma-next/sql-relational-core/ast';
import { codecRefForStorageColumn } from '@prisma-next/sql-relational-core/codec-descriptor-registry';
import type { SqlQueryPlan } from '@prisma-next/sql-relational-core/plan';
import {
  type PolymorphismInfo,
  resolvePolymorphismInfo,
  resolvePrimaryKeyColumn,
} from './collection-contract';
import { buildOrmQueryPlan, deriveParamsFromAst, resolveTableColumns } from './query-plan-meta';
import type { CollectionState, IncludeExpr } from './types';
import { bindWhereExpr } from './where-binding';
import { combineWhereExprs } from './where-utils';

type CursorOrderEntry = {
  readonly column: string;
  readonly direction: 'asc' | 'desc';
  readonly value: unknown;
};

function buildProjection(
  contract: Contract<SqlStorage>,
  tableName: string,
  selectedFields: readonly string[] | undefined,
  tableRef = tableName,
): ProjectionItem[] {
  const columns =
    selectedFields && selectedFields.length > 0
      ? [...selectedFields]
      : resolveTableColumns(contract, tableName);

  return columns.map((column) =>
    ProjectionItem.of(
      column,
      ColumnRef.of(tableRef, column),
      codecRefForStorageColumn(contract.storage, tableName, column),
    ),
  );
}

function createBoundaryExpr(tableName: string, entry: CursorOrderEntry): AnyExpression {
  const comparator: BinaryOp = entry.direction === 'asc' ? 'gt' : 'lt';
  return new BinaryExpr(
    comparator,
    ColumnRef.of(tableName, entry.column),
    LiteralExpr.of(entry.value),
  );
}

function buildLexicographicCursorWhere(
  tableName: string,
  entries: readonly CursorOrderEntry[],
): AnyExpression {
  const branches = entries.map((entry, index): AnyExpression => {
    const branchExprs: AnyExpression[] = [];

    for (const prefixEntry of entries.slice(0, index)) {
      branchExprs.push(
        BinaryExpr.eq(
          ColumnRef.of(tableName, prefixEntry.column),
          LiteralExpr.of(prefixEntry.value),
        ),
      );
    }

    branchExprs.push(createBoundaryExpr(tableName, entry));
    if (branchExprs.length === 1) {
      return branchExprs[0] as AnyExpression;
    }

    return AndExpr.of(branchExprs);
  });

  if (branches.length === 1) {
    return branches[0] as AnyExpression;
  }

  return OrExpr.of(branches);
}

function buildCursorWhere(
  tableName: string,
  orderBy: readonly OrderByItem[] | undefined,
  cursor: Readonly<Record<string, unknown>> | undefined,
): AnyExpression | undefined {
  if (!cursor || !orderBy || orderBy.length === 0) {
    return undefined;
  }

  const entries: CursorOrderEntry[] = [];
  for (const order of orderBy) {
    if (order.expr.kind !== 'column-ref') continue;
    const column = order.expr.column;
    const value = cursor[column];
    if (value === undefined) {
      throw new Error(`Missing cursor value for orderBy column "${column}"`);
    }
    entries.push({
      column,
      direction: order.dir,
      value,
    });
  }

  const firstEntry = entries[0];
  if (entries.length === 1 && firstEntry !== undefined) {
    return createBoundaryExpr(tableName, firstEntry);
  }

  return buildLexicographicCursorWhere(tableName, entries);
}

function createTableRefRemapper(fromTable: string, toTable: string): AstRewriter {
  return {
    columnRef: (col) => (col.table === fromTable ? ColumnRef.of(toTable, col.column) : col),
    tableSource: (source) => {
      if (source.alias === fromTable) return TableSource.named(source.name, toTable);
      if (!source.alias && source.name === fromTable)
        return TableSource.named(source.name, toTable);
      return source;
    },
    eqColJoinOn: (on) =>
      EqColJoinOn.of(
        on.left.table === fromTable ? ColumnRef.of(toTable, on.left.column) : on.left,
        on.right.table === fromTable ? ColumnRef.of(toTable, on.right.column) : on.right,
      ),
  };
}

function buildStateWhere(
  contract: Contract<SqlStorage>,
  tableName: string,
  state: CollectionState,
  options?: {
    readonly filterTableName?: string;
  },
): AnyExpression | undefined {
  const filterTableName = options?.filterTableName;
  const cursorTableName = filterTableName ?? tableName;
  const cursorWhere = buildCursorWhere(cursorTableName, state.orderBy, state.cursor);
  const remappedFilters =
    filterTableName && filterTableName !== tableName
      ? state.filters.map((filter) =>
          filter.rewrite(createTableRefRemapper(filterTableName, tableName)),
        )
      : state.filters;
  const boundCursorWhere = cursorWhere ? bindWhereExpr(contract, cursorWhere) : undefined;
  const remappedCursorWhere =
    boundCursorWhere && filterTableName && filterTableName !== tableName
      ? boundCursorWhere.rewrite(createTableRefRemapper(filterTableName, tableName))
      : boundCursorWhere;
  const filters = remappedCursorWhere ? [...remappedFilters, remappedCursorWhere] : remappedFilters;
  return combineWhereExprs(filters);
}

function buildIncludeOrderArtifacts(
  relationName: string,
  rowAlias: string,
  childOrderBy: readonly OrderByItem[] | undefined,
): {
  readonly childOrderBy: ReadonlyArray<OrderByItem> | undefined;
  readonly hiddenOrderProjection: ReadonlyArray<ProjectionItem>;
  readonly aggregateOrderBy: ReadonlyArray<OrderByItem> | undefined;
} {
  if (!childOrderBy || childOrderBy.length === 0) {
    return {
      childOrderBy: undefined,
      hiddenOrderProjection: [],
      aggregateOrderBy: undefined,
    };
  }

  const hiddenOrderProjection = childOrderBy.map((orderItem, index) =>
    ProjectionItem.of(`${relationName}__order_${index}`, orderItem.expr),
  );
  const aggregateOrderBy = hiddenOrderProjection.map((projection, index) => {
    const orderItem = childOrderBy[index];
    if (!orderItem) {
      throw new Error(`Missing include order metadata at index ${index}`);
    }
    return new OrderByItem(ColumnRef.of(rowAlias, projection.alias), orderItem.dir);
  });

  return {
    childOrderBy,
    hiddenOrderProjection,
    aggregateOrderBy,
  };
}

function buildIncludeChildRowsSelect(
  contract: Contract<SqlStorage>,
  parentTableName: string,
  include: IncludeExpr,
): {
  readonly childRows: SelectAst;
  readonly childProjection: ReadonlyArray<ProjectionItem>;
  readonly rowsAlias: string;
  readonly aggregateOrderBy: ReadonlyArray<OrderByItem> | undefined;
} {
  const childState = include.nested;
  const childTableAlias =
    include.relatedTableName === parentTableName ? `${include.relationName}__child` : undefined;
  const childTableRef = childTableAlias ?? include.relatedTableName;
  const rowsAlias = `${include.relationName}__rows`;
  const childProjection = buildProjection(
    contract,
    include.relatedTableName,
    childState.selectedFields,
    childTableRef,
  );
  const { childOrderBy, hiddenOrderProjection, aggregateOrderBy } = buildIncludeOrderArtifacts(
    include.relationName,
    rowsAlias,
    childState.orderBy,
  );
  const childWhere = buildStateWhere(contract, childTableRef, childState, {
    filterTableName: include.relatedTableName,
  });
  const joinExpr = BinaryExpr.eq(
    ColumnRef.of(childTableRef, include.targetColumn),
    ColumnRef.of(parentTableName, include.localColumn),
  );
  const whereExpr = childWhere ? AndExpr.of([joinExpr, childWhere]) : joinExpr;

  let childRows = SelectAst.from(TableSource.named(include.relatedTableName, childTableAlias))
    .withProjection([...childProjection, ...hiddenOrderProjection])
    .withWhere(whereExpr);

  if (childOrderBy) {
    childRows = childRows.withOrderBy(childOrderBy);
  }
  if (childState.distinctOn && childState.distinctOn.length > 0) {
    childRows = childRows.withDistinctOn(
      childState.distinctOn.map((column) => ColumnRef.of(childTableRef, column)),
    );
  } else if (childState.distinct && childState.distinct.length > 0) {
    childRows = childRows.withDistinct(true);
  }
  if (childState.limit !== undefined) {
    childRows = childRows.withLimit(childState.limit);
  }
  if (childState.offset !== undefined) {
    childRows = childRows.withOffset(childState.offset);
  }

  return {
    childRows,
    childProjection,
    rowsAlias,
    aggregateOrderBy,
  };
}

function buildLateralIncludeArtifacts(
  contract: Contract<SqlStorage>,
  parentTableName: string,
  include: IncludeExpr,
): {
  readonly join: JoinAst;
  readonly projection: ProjectionItem;
} {
  const { childRows, childProjection, rowsAlias, aggregateOrderBy } = buildIncludeChildRowsSelect(
    contract,
    parentTableName,
    include,
  );
  const lateralAlias = `${include.relationName}_lateral`;
  const jsonObjectExpr = JsonObjectExpr.fromEntries(
    childProjection.map((item) =>
      JsonObjectExpr.entry(item.alias, ColumnRef.of(rowsAlias, item.alias)),
    ),
  );

  const aggregateQuery = SelectAst.from(DerivedTableSource.as(rowsAlias, childRows)).withProjection(
    [
      ProjectionItem.of(
        include.relationName,
        JsonArrayAggExpr.of(jsonObjectExpr, 'emptyArray', aggregateOrderBy),
      ),
    ],
  );

  return {
    join: JoinAst.left(DerivedTableSource.as(lateralAlias, aggregateQuery), AndExpr.true(), true),
    projection: ProjectionItem.of(
      include.relationName,
      ColumnRef.of(lateralAlias, include.relationName),
    ),
  };
}

function buildCorrelatedIncludeProjection(
  contract: Contract<SqlStorage>,
  parentTableName: string,
  include: IncludeExpr,
): {
  readonly projection: ProjectionItem;
} {
  const { childRows, childProjection, rowsAlias, aggregateOrderBy } = buildIncludeChildRowsSelect(
    contract,
    parentTableName,
    include,
  );
  const jsonObjectExpr = JsonObjectExpr.fromEntries(
    childProjection.map((item) =>
      JsonObjectExpr.entry(item.alias, ColumnRef.of(rowsAlias, item.alias)),
    ),
  );
  const aggregateQuery = SelectAst.from(DerivedTableSource.as(rowsAlias, childRows)).withProjection(
    [
      ProjectionItem.of(
        include.relationName,
        JsonArrayAggExpr.of(jsonObjectExpr, 'emptyArray', aggregateOrderBy),
      ),
    ],
  );

  return {
    projection: ProjectionItem.of(include.relationName, SubqueryExpr.of(aggregateQuery)),
  };
}

function buildSelectAst(
  contract: Contract<SqlStorage>,
  tableName: string,
  state: CollectionState,
  options: {
    readonly joins?: ReadonlyArray<JoinAst>;
    readonly includeProjection?: ReadonlyArray<ProjectionItem>;
    readonly where?: AnyExpression;
  } = {},
): SelectAst {
  const scalarProjection = buildProjection(contract, tableName, state.selectedFields);
  const projection = [...scalarProjection, ...(options.includeProjection ?? [])];
  const where = options.where ?? buildStateWhere(contract, tableName, state);

  let ast = SelectAst.from(TableSource.named(tableName)).withProjection(projection);
  if (where) {
    ast = ast.withWhere(where);
  }
  if (state.orderBy) {
    ast = ast.withOrderBy(state.orderBy);
  }
  if (state.selectedFields === undefined) {
    ast = ast.withSelectAllIntent({ table: tableName });
  }
  if (state.distinctOn && state.distinctOn.length > 0) {
    ast = ast.withDistinctOn(state.distinctOn.map((column) => ColumnRef.of(tableName, column)));
  } else if (state.distinct && state.distinct.length > 0) {
    ast = ast.withDistinct(true);
  }
  if (state.limit !== undefined) {
    ast = ast.withLimit(state.limit);
  }
  if (state.offset !== undefined) {
    ast = ast.withOffset(state.offset);
  }
  if (options.joins && options.joins.length > 0) {
    ast = ast.withJoins(options.joins);
  }

  return ast;
}

function buildMtiJoins(
  contract: Contract<SqlStorage>,
  polyInfo: PolymorphismInfo,
  variantName: string | undefined,
): { joins: JoinAst[]; projection: ProjectionItem[] } {
  const joins: JoinAst[] = [];
  const projection: ProjectionItem[] = [];
  const pkColumn = resolvePrimaryKeyColumn(contract, polyInfo.baseTable);

  const variantsToJoin = variantName
    ? polyInfo.mtiVariants.filter((v) => v.modelName === variantName)
    : polyInfo.mtiVariants;

  for (const variant of variantsToJoin) {
    const joinType = variantName ? 'inner' : 'left';
    const joinOn = EqColJoinOn.of(
      ColumnRef.of(polyInfo.baseTable, pkColumn),
      ColumnRef.of(variant.table, pkColumn),
    );
    const join =
      joinType === 'inner'
        ? JoinAst.inner(TableSource.named(variant.table), joinOn)
        : JoinAst.left(TableSource.named(variant.table), joinOn);
    joins.push(join);

    const variantColumns = resolveTableColumns(contract, variant.table);
    for (const col of variantColumns) {
      if (col === pkColumn) continue;
      const alias = `${variant.table}__${col}`;
      projection.push(
        ProjectionItem.of(
          alias,
          ColumnRef.of(variant.table, col),
          codecRefForStorageColumn(contract.storage, variant.table, col),
        ),
      );
    }
  }

  return { joins, projection };
}

export function compileSelect(
  contract: Contract<SqlStorage>,
  tableName: string,
  state: CollectionState,
  modelName?: string,
): SqlQueryPlan<Record<string, unknown>> {
  const polyInfo = modelName ? resolvePolymorphismInfo(contract, modelName) : undefined;
  const mtiArtifacts =
    polyInfo && polyInfo.mtiVariants.length > 0
      ? buildMtiJoins(contract, polyInfo, state.variantName)
      : undefined;

  const ast = buildSelectAst(
    contract,
    tableName,
    { ...state, includes: [] },
    mtiArtifacts
      ? {
          joins: mtiArtifacts.joins,
          includeProjection: mtiArtifacts.projection,
        }
      : undefined,
  );

  const { params } = deriveParamsFromAst(ast);
  return buildOrmQueryPlan(contract, ast, params);
}

export function compileRelationSelect(
  contract: Contract<SqlStorage>,
  relatedTableName: string,
  targetColumn: string,
  parentPks: readonly unknown[],
  nestedState: CollectionState,
): SqlQueryPlan<Record<string, unknown>> {
  const inFilter: AnyExpression = BinaryExpr.in(
    ColumnRef.of(relatedTableName, targetColumn),
    ListExpression.fromValues(parentPks),
  );

  return compileSelect(contract, relatedTableName, {
    ...nestedState,
    includes: [],
    limit: undefined,
    offset: undefined,
    filters: [bindWhereExpr(contract, inFilter), ...nestedState.filters],
  });
}

export function compileSelectWithIncludeStrategy(
  contract: Contract<SqlStorage>,
  tableName: string,
  state: CollectionState,
  strategy: 'lateral' | 'correlated',
  modelName?: string,
): SqlQueryPlan<Record<string, unknown>> {
  if (
    state.includes.some((include) => include.scalar !== undefined || include.combine !== undefined)
  ) {
    throw new Error(
      'single-query include strategy does not support scalar include selectors or combine()',
    );
  }

  const includeJoins: JoinAst[] = [];
  const includeProjection: ProjectionItem[] = [];
  const topLevelWhere = buildStateWhere(contract, tableName, state);

  const polyInfo = modelName ? resolvePolymorphismInfo(contract, modelName) : undefined;
  if (polyInfo && polyInfo.mtiVariants.length > 0) {
    const mtiArtifacts = buildMtiJoins(contract, polyInfo, state.variantName);
    includeJoins.push(...mtiArtifacts.joins);
    includeProjection.push(...mtiArtifacts.projection);
  }

  for (const include of state.includes) {
    if (strategy === 'lateral') {
      const artifact = buildLateralIncludeArtifacts(contract, tableName, include);
      includeJoins.push(artifact.join);
      includeProjection.push(artifact.projection);
      continue;
    }
    const artifact = buildCorrelatedIncludeProjection(contract, tableName, include);
    includeProjection.push(artifact.projection);
  }

  const ast = buildSelectAst(
    contract,
    tableName,
    {
      ...state,
      includes: [],
    },
    {
      joins: includeJoins,
      includeProjection,
      ...(topLevelWhere ? { where: topLevelWhere } : {}),
    },
  );

  const { params } = deriveParamsFromAst(ast);
  return buildOrmQueryPlan(contract, ast, params);
}
