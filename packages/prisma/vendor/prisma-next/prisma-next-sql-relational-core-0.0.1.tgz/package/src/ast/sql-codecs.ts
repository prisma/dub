import { type as arktype } from 'arktype';
import { codec, defineCodecs } from './codec-types';

export const SQL_CHAR_CODEC_ID = 'sql/char@1' as const;
export const SQL_VARCHAR_CODEC_ID = 'sql/varchar@1' as const;
export const SQL_INT_CODEC_ID = 'sql/int@1' as const;
export const SQL_FLOAT_CODEC_ID = 'sql/float@1' as const;
export const SQL_TEXT_CODEC_ID = 'sql/text@1' as const;
export const SQL_TIMESTAMP_CODEC_ID = 'sql/timestamp@1' as const;

const lengthParamsSchema = arktype({
  length: 'number.integer > 0',
});

const precisionParamsSchema = arktype({
  'precision?': 'number.integer >= 0 & number.integer <= 6',
});

type LengthTypeHelper = {
  readonly kind: 'fixed' | 'variable';
  readonly maxLength: number;
};

function createLengthTypeHelper(
  kind: LengthTypeHelper['kind'],
): (params: Record<string, unknown>) => LengthTypeHelper {
  return (params) => ({
    kind,
    maxLength: params['length'] as number,
  });
}

const sqlCharCodec = codec<
  typeof SQL_CHAR_CODEC_ID,
  readonly ['equality', 'order', 'textual'],
  string,
  string
>({
  typeId: SQL_CHAR_CODEC_ID,
  targetTypes: ['char'],
  traits: ['equality', 'order', 'textual'],
  encode: (value: string): string => value,
  decode: (wire: string): string => wire.trimEnd(),
  paramsSchema: lengthParamsSchema,
  init: createLengthTypeHelper('fixed'),
  renderOutputType: (typeParams) => {
    const length = typeParams['length'];
    if (length === undefined) return undefined;
    if (typeof length !== 'number' || !Number.isFinite(length) || !Number.isInteger(length)) {
      throw new Error(
        `renderOutputType: expected integer "length" in typeParams for Char, got ${String(length)}`,
      );
    }
    return `Char<${length}>`;
  },
});

const sqlVarcharCodec = codec<
  typeof SQL_VARCHAR_CODEC_ID,
  readonly ['equality', 'order', 'textual'],
  string,
  string
>({
  typeId: SQL_VARCHAR_CODEC_ID,
  targetTypes: ['varchar'],
  traits: ['equality', 'order', 'textual'],
  encode: (value: string): string => value,
  decode: (wire: string): string => wire,
  paramsSchema: lengthParamsSchema,
  init: createLengthTypeHelper('variable'),
  renderOutputType: (typeParams) => {
    const length = typeParams['length'];
    if (length === undefined) return undefined;
    if (typeof length !== 'number' || !Number.isFinite(length) || !Number.isInteger(length)) {
      throw new Error(
        `renderOutputType: expected integer "length" in typeParams for Varchar, got ${String(length)}`,
      );
    }
    return `Varchar<${length}>`;
  },
});

const sqlIntCodec = codec({
  typeId: SQL_INT_CODEC_ID,
  targetTypes: ['int'],
  traits: ['equality', 'order', 'numeric'],
  encode: (value: number): number => value,
  decode: (wire: number): number => wire,
});

const sqlFloatCodec = codec({
  typeId: SQL_FLOAT_CODEC_ID,
  targetTypes: ['float'],
  traits: ['equality', 'order', 'numeric'],
  encode: (value: number): number => value,
  decode: (wire: number): number => wire,
});

const sqlTextCodec = codec({
  typeId: SQL_TEXT_CODEC_ID,
  targetTypes: ['text'],
  traits: ['equality', 'order', 'textual'],
  encode: (value: string): string => value,
  decode: (wire: string): string => wire,
});

const sqlTimestampCodec = codec({
  typeId: SQL_TIMESTAMP_CODEC_ID,
  targetTypes: ['timestamp'],
  traits: ['equality', 'order'],
  encode: (value: string | Date): string => (value instanceof Date ? value.toISOString() : value),
  decode: (wire: string | Date): string => (wire instanceof Date ? wire.toISOString() : wire),
  paramsSchema: precisionParamsSchema,
  renderOutputType: (typeParams) => {
    const precision = typeParams['precision'];
    if (precision === undefined) {
      return 'Timestamp';
    }
    if (
      typeof precision !== 'number' ||
      !Number.isFinite(precision) ||
      !Number.isInteger(precision)
    ) {
      throw new Error(
        `renderOutputType: expected integer "precision" in typeParams for Timestamp, got ${String(precision)}`,
      );
    }
    return `Timestamp<${precision}>`;
  },
});

const codecs = defineCodecs()
  .add('char', sqlCharCodec)
  .add('varchar', sqlVarcharCodec)
  .add('int', sqlIntCodec)
  .add('float', sqlFloatCodec)
  .add('text', sqlTextCodec)
  .add('timestamp', sqlTimestampCodec);

export const sqlCodecDefinitions = codecs.codecDefinitions;
export const sqlDataTypes = codecs.dataTypes;
export type SqlCodecTypes = typeof codecs.CodecTypes;
